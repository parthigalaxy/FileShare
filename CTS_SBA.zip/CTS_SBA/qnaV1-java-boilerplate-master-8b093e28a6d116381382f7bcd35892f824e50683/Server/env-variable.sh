export MYSQL_DATABASE=qnadb
export MYSQL_USER=root
export MYSQL_PASSWORD=root
