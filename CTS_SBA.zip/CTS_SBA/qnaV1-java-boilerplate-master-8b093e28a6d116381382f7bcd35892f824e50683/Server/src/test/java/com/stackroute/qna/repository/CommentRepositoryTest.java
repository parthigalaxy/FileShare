package com.stackroute.qna.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.stackroute.qna.domain.Comment;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@Transactional
public class CommentRepositoryTest {

	@Autowired
	public transient CommentRepository commentRepository;
	
	@Test
	public void findCommentByIdSuccess() throws Exception{
		Optional<Comment> commentO =commentRepository.findById(1);
		assertThat(commentO.isPresent());
	}
	
	@Test
	public void findByQuestionIdSuccess() throws Exception{
		Optional<List<Comment>> commentsO =commentRepository.findByQuestionId(1);
		assertThat(commentsO.isPresent());
	}
	
}
