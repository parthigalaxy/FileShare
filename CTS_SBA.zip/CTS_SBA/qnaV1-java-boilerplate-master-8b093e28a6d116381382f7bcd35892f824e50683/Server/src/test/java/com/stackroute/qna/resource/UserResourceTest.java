package com.stackroute.qna.resource;


import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.qna.domain.User;
import com.stackroute.qna.service.SecurityTokenGenrator;
import com.stackroute.qna.service.UserService;

@RunWith(SpringRunner.class)
@WebMvcTest(UserResource.class)
public class UserResourceTest {

	@Autowired
	private transient MockMvc mvc;
	
	@MockBean
	private transient UserService userService;
	
	@MockBean
	private transient SecurityTokenGenrator securityTokenGenrator;
	
	private transient User user;
	
	@InjectMocks
	UserResource userResource;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		user = new User("test", "test", "test@test.com", "123456", "123456", new Date());
	}
	
	@Test
	public void testregisterUserSuccess() throws Exception{
		when(userService.saveUser(user)).thenReturn(true);
		mvc.perform(post("/user/register").contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.content(jsonToString(user))).andExpect(status().isCreated());
		verify(userService, times(1)).saveUser(Mockito.any(User.class));
		verifyNoMoreInteractions(userService);
	}
	
	@Test
	public void testLoginUserSuccess() throws Exception{
		when(userService.saveUser(user)).thenReturn(true);
		when(userService.findByEmailAddressAndPassword(user.getEmailAddress(), user.getPassword())).thenReturn(user);
		mvc.perform(post("/user/login").contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.content(jsonToString(user))).andExpect(status().isOk());
		verify(userService, times(1)).findByEmailAddressAndPassword(user.getEmailAddress(), user.getPassword());
		verifyNoMoreInteractions(userService);
	}
	
	private static String jsonToString(final Object obj) throws JsonProcessingException {
		String result;
		try {
			final ObjectMapper mapper= new ObjectMapper();
			final String json=mapper.writeValueAsString(obj);
			result=json;
		}catch(JsonProcessingException e) {
			result = "Json processing error";
		}
		return result;
	}
	
}
