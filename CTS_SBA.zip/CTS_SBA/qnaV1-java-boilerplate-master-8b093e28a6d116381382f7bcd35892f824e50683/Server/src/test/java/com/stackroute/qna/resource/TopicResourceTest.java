package com.stackroute.qna.resource;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.qna.domain.Topic;
import com.stackroute.qna.service.TopicService;

@RunWith(SpringRunner.class)
@WebMvcTest(TopicResource.class)
public class TopicResourceTest {
	
	@Autowired
	private transient MockMvc mvc;
	
	@MockBean
	private transient TopicService topicService;
	
	@InjectMocks
	private TopicResource topicResource;
	
	private transient Optional<List<Topic>> topicsO;
	private transient Optional<Topic> topicO;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mvc = MockMvcBuilders.standaloneSetup(topicResource).build();
		List<Topic> topics = new ArrayList<Topic>();
		topics.add(this.prepareTopic(1,"test1"));
		topics.add(this.prepareTopic(2,"test2"));
		topics.add(this.prepareTopic(3,"test3"));
		this.topicsO = Optional.of(topics);
		this.topicO =  Optional.of(this.prepareTopic(4,"test3"));
	}
	
	public Topic prepareTopic(int id,String description) {
		Topic topic = new Topic();
		topic.setId(id);
		topic.setDescription(description);
		return topic;
	}
	
	@Test
	public void testretrieveAllTopicsSuccess() throws JsonProcessingException, Exception{
		when(topicService.retrieveAllTopics()).thenReturn(this.topicsO.get());
		mvc.perform(get("/api/topic").contentType(MediaType.APPLICATION_JSON).content(jsonToString(this.topicsO.get())))
			.andExpect(status().isOk());
		verify(topicService, times(1)).retrieveAllTopics();
		verifyNoMoreInteractions(topicService);
	}
	
	@Test
	public void testretrieveAllTopicSuccess() throws JsonProcessingException, Exception{
		when(topicService.retrieveTopic(1)).thenReturn(this.topicO.get());
		mvc.perform(get("/api/topic/{topicId}",1).contentType(MediaType.APPLICATION_JSON).content(jsonToString(this.topicO.get())))
			.andExpect(status().isOk());
		verify(topicService, times(1)).retrieveTopic(1);
		verifyNoMoreInteractions(topicService);
	}
	
	private static String jsonToString(final Object obj) throws JsonProcessingException {
		String result;
		try {
			final ObjectMapper mapper= new ObjectMapper();
			final String json=mapper.writeValueAsString(obj);
			result=json;
		}catch(JsonProcessingException e) {
			result = "Json processing error";
		}
		return result;
	}
}
