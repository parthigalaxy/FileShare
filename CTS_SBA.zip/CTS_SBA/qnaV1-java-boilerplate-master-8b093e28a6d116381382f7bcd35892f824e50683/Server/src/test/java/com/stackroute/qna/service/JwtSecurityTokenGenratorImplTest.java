package com.stackroute.qna.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.stackroute.qna.domain.User;

public class JwtSecurityTokenGenratorImplTest {

	@InjectMocks
	private transient JwtSecurityTokenGenratorImpl jwtSecurityTokenGenratorImpl;
	
	private transient User user;
	
	@Before
	public void testMock() {
		MockitoAnnotations.initMocks(this);
		user = new User("test", "test", "test@test.com", "test", "test", new Date());
	}
	

	@Test
	public void testGeneateTokenSuccess() {
		Map<String, String> tokentMap = this.jwtSecurityTokenGenratorImpl.geneateToken(user);
		assertNotNull(tokentMap);
//		System.out.println(tokentMap.get("token"));
		assertNotNull(tokentMap.get("token"));
		assertEquals("User Successfully loged in", tokentMap.get("message"));
	}
	
}
