package com.stackroute.qna.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.qna.domain.Comment;
import com.stackroute.qna.domain.Question;
import com.stackroute.qna.exception.ResourceNotFoundException;
import com.stackroute.qna.repository.CommentRepository;
import com.stackroute.qna.repository.QuestionRepository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CommentServiceImplTest {
	
	@Mock
	private transient CommentRepository commentRepository;
	
	@Mock
	private transient QuestionRepository questionRepository;
	
	@InjectMocks
	private transient CommentServiceImpl commentServiceImpl;
	
	private transient Optional<List<Comment>> commentsO;
	private transient Optional<Question> questionO;
	
	@Before
	public void testMock() {
		MockitoAnnotations.initMocks(this);
		List<Comment> comments = new ArrayList<Comment>();
		comments.add(this.prepareComment(1,"test1"));
		comments.add(this.prepareComment(2,"test2"));
		comments.add(this.prepareComment(3,"test3"));
		this.commentsO = Optional.of(comments);
		this.questionO = Optional.of(this.prepareQuestion(1));
	}
	
	public Comment prepareComment(int id,String commenttxt) {
		Comment comment = new Comment();
		comment.setId(id);
		comment.setComment(commenttxt);
		comment.setPostedBy("test@test.com");
		comment.setCommentDate(new Date());
		comment.setQuestion(this.prepareQuestion(1));
		return comment;
	}
	
	public Question prepareQuestion(int id) {
		Question question = new Question();
		question.setId(id);
		return question;
	}
	
	@Test
	public void testMockCreation() {
		assertNotNull("use @InjectionMocks on CommentServiceImpl", this.commentsO);
	}
	
	@Test
	public void testRetrieveCommentsSuccess() {
		when(this.commentRepository.findByQuestionId(1)).thenReturn(commentsO);
		final Optional<List<Comment>> commentsO = this.commentServiceImpl.retrieveComments(1);
		assertEquals(this.commentsO,commentsO);
		verify(this.commentRepository,times(1)).findByQuestionId(1);
	}
	
	@Test
	public void testPostCommentSuccess() throws ResourceNotFoundException {
		when(this.questionRepository.findById(1)).thenReturn(this.questionO);
		Comment comment = this.prepareComment(4,"test4");
		when(this.commentRepository.save(comment)).thenReturn(comment);
		Comment commentOut =  this.commentServiceImpl.postComment(1, comment);
		assertNotNull("Comment saved successfully",commentOut);
		assertNotNull("Question ",commentOut.getQuestion());
		verify(this.questionRepository,times(1)).findById(1);
		verify(this.commentRepository,times(1)).save(comment);
	}
	
	@Test(expected=ResourceNotFoundException.class)
	public void testPostCommentFailure() throws ResourceNotFoundException{
		when(this.questionRepository.findById(1)).thenReturn(Optional.empty());
		Comment comment = this.prepareComment(4,"test4");
		when(this.commentRepository.save(comment)).thenReturn(null);
		Comment commentOut =  this.commentServiceImpl.postComment(1, comment);
		assertNull("Comment saved failed",commentOut);
		verify(this.questionRepository,times(1)).findById(1);
	}
	
	@Test
	public void testDeleteCommentSuccess() throws ResourceNotFoundException{
		when(this.questionRepository.exists(1)).thenReturn(true);
		Comment comment = this.prepareComment(4,"test4");
		when(this.commentRepository.findById(4)).thenReturn(Optional.ofNullable(comment));
		doNothing().when(commentRepository).delete(comment);
		final boolean flag= this.commentServiceImpl.deleteComment(1, 4);
		assertTrue("Deleting Comment Success",flag);
		verify(this.questionRepository,times(1)).exists(1);
	}
	
	@Test(expected=ResourceNotFoundException.class)
	public void testDeleteCommentFailure() throws ResourceNotFoundException{
		when(this.questionRepository.exists(1)).thenReturn(false);
		Comment comment = this.prepareComment(4,"test4");
		when(this.commentRepository.findById(4)).thenReturn(Optional.ofNullable(comment));
		doNothing().when(commentRepository).delete(comment);
		final boolean flag= this.commentServiceImpl.deleteComment(1, 4);
		assertFalse("Deleting Comment Failure",flag);
		verify(this.questionRepository,times(1)).exists(1);
	}
	
	@Test
	public void testDeleteCommentsSuccess() throws ResourceNotFoundException{
		when(this.questionRepository.exists(1)).thenReturn(true);
		Comment comment = this.prepareComment(4,"test4");
		when(this.commentRepository.findByQuestionId(1)).thenReturn(this.commentsO);
		doNothing().when(commentRepository).delete(comment);
		final boolean flag= this.commentServiceImpl.deleteComments(1);
		assertTrue("Deleting Comments Success",flag);
		verify(this.questionRepository,times(1)).exists(1);
	}

}
