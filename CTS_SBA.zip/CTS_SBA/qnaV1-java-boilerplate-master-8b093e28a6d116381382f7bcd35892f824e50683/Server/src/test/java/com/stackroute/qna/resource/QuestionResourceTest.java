package com.stackroute.qna.resource;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.qna.domain.Question;
import com.stackroute.qna.service.QuestionService;

@RunWith(SpringRunner.class)
@WebMvcTest(QuestionResource.class)
public class QuestionResourceTest {

	@Autowired
	private transient MockMvc mvc;
	
	@MockBean
	private transient QuestionService questionService;
	
	@InjectMocks
	private QuestionResource questionResource;
	
	private transient Optional<List<Question>> questionsO;
	private transient Optional<Question> questionO;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mvc = MockMvcBuilders.standaloneSetup(questionResource).build();
		List<Question> question = new ArrayList<Question>();
		question.add(this.prepareQuestion(1,"test1"));
		question.add(this.prepareQuestion(2,"test2"));
		question.add(this.prepareQuestion(3,"test3"));
		this.questionsO = Optional.of(question);
		this.questionO = Optional.of(this.prepareQuestion(4,"test4"));
	}
	
	public Question prepareQuestion(int id, String questionTxt) {
		Question question = new Question();
		question.setId(id);
		question.setQuestion(questionTxt);
		question.setPostedBy("test@test.com");
		question.setPostedDate(new Date());
		return question;
	}
	
	@Test
	public void testRetrieveQuestionsSuccess() throws JsonProcessingException, Exception{
		when(questionService.retrieveQuestions(1)).thenReturn(this.questionsO);
		mvc.perform(get("/api/question/{topicId}",1).contentType(MediaType.APPLICATION_JSON).content(jsonToString(this.questionsO.get())))
			.andExpect(status().isOk());
		verify(questionService, times(1)).retrieveQuestions(1);
		verifyNoMoreInteractions(questionService);
	}
	
	@Test
	public void testRetrieveQuestionSuccess() throws JsonProcessingException, Exception{
		when(questionService.retrieveQuestion(1)).thenReturn(this.questionO.get());
		mvc.perform(get("/api/question/get/{questionId}",1).contentType(MediaType.APPLICATION_JSON).content(jsonToString(this.questionO.get())))
			.andExpect(status().isOk());
		verify(questionService, times(1)).retrieveQuestion(1);
		verifyNoMoreInteractions(questionService);
	}
	
	@Test
	public void testPostQuestionSuccess() throws Exception{
		when(questionService.postQuestion(1,this.questionO.get())).thenReturn(this.questionO.get());
		String token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0ZXN0QHRlc3QuY29tIiwiaWF0IjoxNTM3ODA1MTkyfQ.Zj6N9ZCuzKEa0SJ0uD6nRqCao3N5C4GHNTtCtBwMIFU";
		mvc.perform(post("/api/question/{topicId}",1).header("Authorization", "Bearer "+token).contentType(MediaType.APPLICATION_JSON).content(jsonToString(this.questionO.get())))
			.andExpect(status().isCreated());
		verify(questionService, times(1)).postQuestion(Mockito.any(Integer.class),Mockito.any(Question.class));
		verifyNoMoreInteractions(questionService);
	}
	
	@Test
	public void testdeleteComment() throws Exception{
		when(questionService.deleteQuestion(1,1)).thenReturn(true);
		mvc.perform(delete("/api/question/{topicId}/{questionId}",1,1)).andExpect(status().isOk());
		verify(questionService, times(1)).deleteQuestion(1,1);
		verifyNoMoreInteractions(questionService);
	}
	
	private static String jsonToString(final Object obj) throws JsonProcessingException {
		String result;
		try {
			final ObjectMapper mapper= new ObjectMapper();
			final String json=mapper.writeValueAsString(obj);
			result=json;
		}catch(JsonProcessingException e) {
			result = "Json processing error";
		}
		return result;
	}
	
}
