package com.stackroute.qna.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.qna.domain.User;
import com.stackroute.qna.exception.UserAlreadyExistException;
import com.stackroute.qna.exception.UserNotFoundException;
import com.stackroute.qna.exception.UserValidationException;
import com.stackroute.qna.repository.UserRepository;

public class UserServiceImplTest {

	@Mock
	private transient UserRepository userRepository;
	
	private transient User user;
	
	@InjectMocks
	private transient UserServiceImpl userServiceImpl;

	private transient Optional<User> options;

	@Before
	public void testMock() {
		MockitoAnnotations.initMocks(this);
		user = new User("test", "test", "test@test.com", "123456", "123456", new Date());
		options = Optional.of(user);
	}
	
	@Test
	public void testMockCreation() {
		assertNotNull("use @InjectionMocks on userServiceImpl", user);
	}
	
	@Test
	public void testSaveUserSuccess() throws UserAlreadyExistException, UserNotFoundException,UserValidationException{
		when(userRepository.save(this.user)).thenReturn(user);
		when(userRepository.findByEmailAddress(user.getEmailAddress())).thenReturn(Optional.empty());
		final boolean flag= this.userServiceImpl.saveUser(user);
		assertEquals("User registred successfully ", true, flag);
		verify(userRepository,times(1)).save(user);
	}
	
	@Test(expected=UserAlreadyExistException.class)
	public void testSaveUserFailure() throws UserAlreadyExistException, UserNotFoundException, UserValidationException{
		when(userRepository.findByEmailAddress(user.getEmailAddress())).thenReturn(options);
		when(userRepository.save(user)).thenReturn(user);
		userServiceImpl.saveUser(user);
	}
	
	@Test
	public void testValidateUserSuccess() throws UserNotFoundException{
		when(userRepository.findByEmailAddressAndPassword(user.getEmailAddress(), user.getPassword())).thenReturn(user);
		User userRes = userServiceImpl.findByEmailAddressAndPassword(user.getEmailAddress(), user.getPassword());
		assertNotNull(userRes);
		assertEquals("test@test.com", userRes.getEmailAddress());
		verify(userRepository,times(1)).findByEmailAddressAndPassword(user.getEmailAddress(), user.getPassword());
	}
	
	@Test(expected=UserNotFoundException.class)
	public void testValidateUserFailure() throws UserNotFoundException{
		when(userRepository.findByEmailAddressAndPassword(user.getEmailAddress(), user.getPassword())).thenReturn(null);
		userServiceImpl.findByEmailAddressAndPassword(user.getEmailAddress(), user.getPassword());
	}
	
}
