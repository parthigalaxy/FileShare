package com.stackroute.qna.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.qna.domain.Question;
import com.stackroute.qna.domain.Topic;
import com.stackroute.qna.repository.TopicRepository;

public class TopicServiceImplTest {
	
	@Mock
	private transient TopicRepository topicRepository;
	
	@InjectMocks
	private transient TopicServiceImpl topicServiceImpl;
	
	private transient Optional<Topic> topicO;
	private transient Optional<List<Topic>> topicsO;

	@Before
	public void testMock() {
		MockitoAnnotations.initMocks(this);
		List<Topic> topics = new ArrayList<Topic>();
		topics.add(this.prepareTopic(1,"test1"));
		topics.add(this.prepareTopic(2,"test2"));
		topics.add(this.prepareTopic(3,"test3"));
		this.topicsO = Optional.of(topics);
		this.topicO =  Optional.of(this.prepareTopic(4,"test3"));
	}
	
	public Topic prepareTopic(int id,String description) {
		Topic topic = new Topic();
		topic.setId(id);
		topic.setDescription(description);
		return topic;
	}
	
	@Test
	public void testMockCreation() {
		assertNotNull("use @InjectionMocks on TopicServiceImpl", this.topicsO);
	}
	
	@Test
	public void testAetrieveAllTopicsSuccess() {
		when(this.topicRepository.findAll()).thenReturn(this.topicsO.get());
		final List<Topic> topics = this.topicServiceImpl.retrieveAllTopics();
		assertEquals(this.topicsO.get(),topics);
		verify(this.topicRepository,times(1)).findAll();
	}
	
	@Test
	public void testAetrieveAllTopicSuccess() {
		when(this.topicRepository.findOne(1)).thenReturn(this.topicO.get());
		final Topic topic = this.topicServiceImpl.retrieveTopic(1);
		assertEquals(this.topicO.get(),topic);
		verify(this.topicRepository,times(1)).findOne(1);
	}
	
}
