package com.stackroute.qna.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Date;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.stackroute.qna.domain.User;


@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@Transactional
public class UserRepositoryTest {
	
	@Autowired
	public transient UserRepository userRepository; 
	
	private User user;
	private User user1;
	
	@Before
	public void setup() throws Exception{
		user = new User("testJohn", "John", "Jenny@gmail.com", "123456", "123456", new Date());
		user1 = new User("testJohn", "John", "John1@gmail.com", "123456", "123456", new Date());
	}
	
	@SuppressWarnings("unlikely-arg-type")
	@Test
	public void testRegisterUserSuccess() throws Exception{
		userRepository.save(this.user);
		Optional<User> userO = userRepository.findByEmailAddress(this.user.getEmailAddress());
		assertThat(userO.equals(this.user));
	}
	
	@Test
	public void testFindByUserIdAndPasswordSuccess() throws Exception{
		userRepository.save(this.user1);
		User userResp = userRepository.findByEmailAddressAndPassword(this.user1.getEmailAddress(), this.user1.getPassword());
		assertThat(userResp.equals(user));
	}
	
	@Test
	public void testDeleteByUserIdSuccess() throws Exception{
		userRepository.delete(this.user);
		Optional<User> userO = userRepository.findByEmailAddress(this.user.getEmailAddress());
		assertThat(!userO.isPresent());
	}


}
