package com.stackroute.qna.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.qna.domain.Comment;
import com.stackroute.qna.domain.Question;
import com.stackroute.qna.domain.Topic;
import com.stackroute.qna.exception.ResourceNotFoundException;
import com.stackroute.qna.repository.QuestionRepository;
import com.stackroute.qna.repository.TopicRepository;

public class QuestionServiceImplTest {

	@Mock
	private transient QuestionRepository questionRepository;
	
	@Mock
	private transient TopicRepository topicRepository;
	
	@Mock
	private transient CommentService commentService;
	
	@InjectMocks
	private transient QuestionServiceImpl questionServiceImpl;
	
	private transient Optional<Topic> topicO;
	private transient Optional<List<Question>> questionsO;
	private transient Optional<Question> questionO;
	
	@Before
	public void testMock() {
		MockitoAnnotations.initMocks(this);
		MockitoAnnotations.initMocks(this.commentService);
		List<Question> question = new ArrayList<Question>();
		question.add(this.prepareQuestion(1,"test1"));
		question.add(this.prepareQuestion(2,"test2"));
		question.add(this.prepareQuestion(3,"test3"));
		this.questionsO = Optional.of(question);
		this.questionO = Optional.of(this.prepareQuestion(4,"test4"));
		this.topicO =  Optional.of(this.prepareTopic(1));
	}
	
	public Question prepareQuestion(int id, String questionTxt) {
		Question question = new Question();
		question.setId(id);
		question.setQuestion(questionTxt);
		question.setPostedBy("test@test.com");
		question.setPostedDate(new Date());
		question.setTopic(this.prepareTopic(1));
		return question;
	}
	
	public Topic prepareTopic(int id) {
		Topic topic = new Topic();
		topic.setId(id);
		return topic;
	}
	
	@Test
	public void testMockCreation() {
		assertNotNull("use @InjectionMocks on QuestionServiceImpl", this.questionsO);
	}
	
	@Test
	public void testRetrieveQuestionsSuccess() {
		when(this.questionRepository.findByTopicId(1)).thenReturn(this.questionsO);
		final Optional<List<Question>> questionsO = this.questionServiceImpl.retrieveQuestions(1);
		assertEquals(this.questionsO,questionsO);
		verify(this.questionRepository,times(1)).findByTopicId(1);
	}
	
	@Test
	public void testRetrieveQuestionSuccess() {
		when(this.questionRepository.findOne(1)).thenReturn(this.questionO.get());
		final Question question = this.questionServiceImpl.retrieveQuestion(1);
		assertEquals(this.questionO.get(),question);
		verify(this.questionRepository,times(1)).findOne(1);
	}
	
	@Test
	public void testPostQuestionSuccess() throws ResourceNotFoundException {
		when(this.topicRepository.findOne(1)).thenReturn(this.topicO.get());
		when(this.questionRepository.save(this.questionO.get())).thenReturn(this.questionO.get());
		Question questionOut =  this.questionServiceImpl.postQuestion(1, this.questionO.get());
		assertNotNull("Question saved successfully",questionOut);
		assertNotNull("Topic ",questionOut.getTopic());
		verify(this.topicRepository,times(1)).findOne(1);
		verify(this.questionRepository,times(1)).save(this.questionO.get());
	}
	
	@Test(expected=ResourceNotFoundException.class)
	public void testPostQuestionFailure() throws ResourceNotFoundException {
		when(this.topicRepository.findOne(1)).thenReturn(null);
		when(this.questionRepository.save(this.questionO.get())).thenReturn(this.questionO.get());
		Question questionOut =  this.questionServiceImpl.postQuestion(1, this.questionO.get());
		assertNotNull("Question saved failed",questionOut);
		verify(this.topicRepository,times(1)).findOne(1);
	}
	
	@Test
	public void testDeleteQuestionSuccess() throws ResourceNotFoundException{
		when(this.topicRepository.exists(1)).thenReturn(true);
		when(this.commentService.deleteComments(1)).thenReturn(true);
		when(this.questionRepository.findById(1)).thenReturn(this.questionO);
		doNothing().when(questionRepository).delete(this.questionO.get());
		final boolean flag= this.questionServiceImpl.deleteQuestion(1, 1);
		assertTrue("Deleting Question Success",flag);
		verify(this.topicRepository,times(1)).exists(1);
	}

	@Test(expected=ResourceNotFoundException.class)
	public void testDeleteQuestionFailure() throws ResourceNotFoundException{
		when(this.topicRepository.exists(1)).thenReturn(false);
		when(this.commentService.deleteComments(1)).thenReturn(true);
		when(this.questionRepository.findById(1)).thenReturn(this.questionO);
		doNothing().when(questionRepository).delete(this.questionO.get());
		final boolean flag= this.questionServiceImpl.deleteQuestion(1, 1);
		assertTrue("Deleting Question Failure",flag);
		verify(this.topicRepository,times(1)).exists(1);
	}
	
}
