package com.stackroute.qna.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.validator.constraints.Email;

@Entity
@Table(name="tbl_user")
public class User {

	public User() {
		super();
	}
	
	public User(String firstName, String lastName, String emailAddress,String password,String confirmPassword, Date createdDate) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailAddress = emailAddress;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.createdDate = createdDate;
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	@Pattern(regexp="[a-zA-Z]+")
	@NotNull
	@Column(name="first_name")
	private String firstName;
	@Pattern(regexp="[a-zA-Z]+")
	@NotNull
	@Column(name="last_name")
	private String lastName;
	@NotNull
	@Email
	@Column(name="email_address")
	private String emailAddress;
	@NotNull
	@Column(name="password")
	private String password;
	@NotNull
	@Column(name="confirm_password")
	private String confirmPassword;
	@Column(name="created_date")
	@CreationTimestamp
	private Date createdDate;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
}
