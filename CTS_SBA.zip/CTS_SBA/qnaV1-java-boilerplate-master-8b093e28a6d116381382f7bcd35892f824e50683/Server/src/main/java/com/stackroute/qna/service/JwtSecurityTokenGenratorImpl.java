package com.stackroute.qna.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.stackroute.qna.domain.User;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JwtSecurityTokenGenratorImpl implements SecurityTokenGenrator {

	@Override
	public Map<String, String> geneateToken(User user) {
		String jwtToken = Jwts.builder().setSubject(user.getEmailAddress()).setIssuedAt(new Date())
				.signWith(SignatureAlgorithm.HS256, "secretkey").compact();
		Map<String, String> tokenMap = new HashMap<>();
		tokenMap.put("token", jwtToken);
		tokenMap.put("message", "User Successfully loged in");
		return tokenMap;
	}

}
