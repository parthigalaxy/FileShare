package com.stackroute.qna.service;

import com.stackroute.qna.domain.User;
import com.stackroute.qna.exception.UserAlreadyExistException;
import com.stackroute.qna.exception.UserNotFoundException;
import com.stackroute.qna.exception.UserValidationException;

public interface UserService {
	
	boolean saveUser(User user) throws UserAlreadyExistException,UserNotFoundException, UserValidationException;
	
	User findByEmailAddressAndPassword(String emailAddress,String password) throws UserNotFoundException;

}
