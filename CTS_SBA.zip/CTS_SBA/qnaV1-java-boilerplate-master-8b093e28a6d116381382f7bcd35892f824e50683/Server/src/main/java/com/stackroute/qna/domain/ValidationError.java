package com.stackroute.qna.domain;

import java.util.ArrayList;
import java.util.List;

public class ValidationError {

	private List<ErrorDetails> errorDetails = new ArrayList<ErrorDetails>();

	public void addErrorDetails(String field,String message) {
		errorDetails.add(new ErrorDetails(field,message));
	}

	public List<ErrorDetails> getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(List<ErrorDetails> errorDetails) {
		this.errorDetails = errorDetails;
	}
	
	
}
