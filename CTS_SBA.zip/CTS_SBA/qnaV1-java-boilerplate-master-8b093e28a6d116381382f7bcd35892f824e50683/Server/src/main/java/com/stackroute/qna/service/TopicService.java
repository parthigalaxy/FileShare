package com.stackroute.qna.service;

import java.util.List;

import com.stackroute.qna.domain.Topic;

public interface TopicService {

	List<Topic> retrieveAllTopics();

	Topic retrieveTopic(Integer topicId);
	
}
