package com.stackroute.qna.service;

import java.util.Map;

import com.stackroute.qna.domain.User;

public interface SecurityTokenGenrator {
	
	Map<String,String> geneateToken(User user);

}
