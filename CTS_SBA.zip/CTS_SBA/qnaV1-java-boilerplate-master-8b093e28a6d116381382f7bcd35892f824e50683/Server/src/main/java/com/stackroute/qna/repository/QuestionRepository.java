package com.stackroute.qna.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stackroute.qna.domain.Question;

@Repository
public interface QuestionRepository  extends JpaRepository<Question, Integer>{
	
	Optional<Question> findById(Integer questionId);
	
	Optional<List<Question>> findByTopicId(Integer topicId);

}
