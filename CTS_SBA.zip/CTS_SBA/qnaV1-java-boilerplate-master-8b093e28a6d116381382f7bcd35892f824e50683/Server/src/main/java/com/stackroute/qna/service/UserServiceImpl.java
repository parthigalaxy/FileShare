package com.stackroute.qna.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.qna.domain.User;
import com.stackroute.qna.exception.UserAlreadyExistException;
import com.stackroute.qna.exception.UserNotFoundException;
import com.stackroute.qna.exception.UserValidationException;
import com.stackroute.qna.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	
	private UserRepository userRepository;
	
	@Autowired
	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	@Override
	public boolean saveUser(User user) throws UserAlreadyExistException, UserNotFoundException, UserValidationException {
		String emailAddress = (null != user)?user.getEmailAddress():null;
		if(user == null) {
			throw new UserNotFoundException("Please check the EmailAddress");
		}
		if(!user.getPassword().equals(user.getConfirmPassword())) {
			throw new UserValidationException("Please check the password");
		}
		Optional<User> userO = userRepository.findByEmailAddress(emailAddress);
		if(userO.isPresent()) {
			throw new UserAlreadyExistException("User with Id is alrady exist");
		}
		userRepository.save(user);
		return true;
	}

	@Override
	public User findByEmailAddressAndPassword(String emailAddress, String password) throws UserNotFoundException {
		User user = userRepository.findByEmailAddressAndPassword(emailAddress, password);
		if(user == null) {
			throw new UserNotFoundException("Please check the user details");
		}
		return user;
	}

}
