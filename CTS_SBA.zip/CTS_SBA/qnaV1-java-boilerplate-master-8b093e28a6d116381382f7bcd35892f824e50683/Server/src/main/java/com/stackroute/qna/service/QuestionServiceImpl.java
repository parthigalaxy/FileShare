package com.stackroute.qna.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.qna.domain.Question;
import com.stackroute.qna.domain.Topic;
import com.stackroute.qna.exception.ResourceNotFoundException;
import com.stackroute.qna.repository.QuestionRepository;
import com.stackroute.qna.repository.TopicRepository;
import com.stackroute.qna.resource.CommentResource;

@Service
public class QuestionServiceImpl implements QuestionService {
	
	private static final Logger logger = LoggerFactory.getLogger(QuestionServiceImpl.class);
	
	private QuestionRepository questionRepository;
	
	private TopicRepository topicRepository;
	
	private CommentService commentService;
	
	@Autowired
	public QuestionServiceImpl(QuestionRepository questionRepository,TopicRepository topicRepository,CommentService commentService) {
		super();
		this.questionRepository = questionRepository;
		this.topicRepository = topicRepository;
		this.commentService = commentService;
	}
	

	@Override
	public Optional<List<Question>> retrieveQuestions(Integer topicId) {
		return this.questionRepository.findByTopicId(topicId);
	}

	@Override
	public Question postQuestion(Integer topicId, Question question) throws ResourceNotFoundException {
		Topic topicRes = this.topicRepository.findOne(topicId);
		Optional<Topic> topicO = Optional.ofNullable(topicRes);
		return topicO.map(topic ->{
			question.setTopic(topic);
			return this.questionRepository.save(question);
		}).orElseThrow(()-> new ResourceNotFoundException("TopicId -> "+topicId+" not found"));
	}

	@Override
	public boolean deleteQuestion(Integer topicId, Integer questionId) throws ResourceNotFoundException {
		if(!this.topicRepository.exists(topicId)) {
			throw new ResourceNotFoundException("TopicId -> "+topicId+" not found");
		}
		return this.questionRepository.findById(questionId).map(question -> {
			try {
				this.commentService.deleteComments(questionId);
			} catch (ResourceNotFoundException e) {
				logger.error("ResourceNotFoundException "+ e);
			}
			this.questionRepository.delete(question);
			return true;
		}).orElseThrow(()-> new ResourceNotFoundException("QuestionId -> "+questionId+" not found"));
	}


	@Override
	public Question retrieveQuestion(Integer questionId) {
		return this.questionRepository.findOne(questionId);
	}


}
