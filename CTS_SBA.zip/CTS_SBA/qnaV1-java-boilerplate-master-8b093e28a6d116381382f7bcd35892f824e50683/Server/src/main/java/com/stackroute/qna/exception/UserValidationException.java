package com.stackroute.qna.exception;

@SuppressWarnings("serial")
public class UserValidationException extends Exception{

	private String message;
	
	public UserValidationException(String message) {
		super(message);
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String toString() {
		return "UserValidationException [message :"+message+"]";
	}

}