package com.stackroute.qna.service;

import java.util.List;
import java.util.Optional;

import com.stackroute.qna.domain.Comment;
import com.stackroute.qna.exception.ResourceNotFoundException;

public interface CommentService {

	Optional<List<Comment>> retrieveComments(Integer questionId);
	
	Comment postComment(Integer questionId,Comment comment) throws ResourceNotFoundException;
	
	boolean deleteComment(Integer questionId,Integer commentId) throws ResourceNotFoundException;
	
	boolean deleteComments(Integer questionId) throws ResourceNotFoundException;
}
