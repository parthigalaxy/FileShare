package com.stackroute.qna.service;

import java.util.List;
import java.util.Optional;

import com.stackroute.qna.domain.Question;
import com.stackroute.qna.exception.ResourceNotFoundException;

public interface QuestionService {
	
	Optional<List<Question>> retrieveQuestions(Integer topicId);
	
	Question postQuestion(Integer topicId,Question question) throws ResourceNotFoundException;
	
	boolean deleteQuestion(Integer topicId,Integer questionId) throws ResourceNotFoundException;

	Question retrieveQuestion(Integer questionId);

}