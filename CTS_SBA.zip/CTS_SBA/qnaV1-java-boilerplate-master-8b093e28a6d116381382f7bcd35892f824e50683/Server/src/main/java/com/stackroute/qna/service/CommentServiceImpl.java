package com.stackroute.qna.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.qna.domain.Comment;
import com.stackroute.qna.exception.ResourceNotFoundException;
import com.stackroute.qna.repository.CommentRepository;
import com.stackroute.qna.repository.QuestionRepository;

@Service
public class CommentServiceImpl implements CommentService {


	private CommentRepository commentRepository;
	
	private QuestionRepository questionRepository;
	
	@Autowired
	public CommentServiceImpl(CommentRepository commentRepository,QuestionRepository questionRepository) {
		super();
		this.commentRepository = commentRepository;
		this.questionRepository = questionRepository;
	}
	
	@Override
	public Optional<List<Comment>> retrieveComments(Integer questionId) {
		return this.commentRepository.findByQuestionId(questionId);
	}

	@Override
	public Comment postComment(Integer questionId,Comment comment) throws ResourceNotFoundException {
		return this.questionRepository.findById(questionId).map(question -> {
			comment.setQuestion(question);
			return this.commentRepository.save(comment);
		}).orElseThrow(()-> new ResourceNotFoundException("QuestionId -> "+questionId+" not found"));
	}

	@Override
	public boolean deleteComment(Integer questionId,Integer commentId) throws ResourceNotFoundException  {
		if(!this.questionRepository.exists(questionId)) {
			throw new ResourceNotFoundException("QuestionId -> "+questionId+" not found");
		}
		return this.commentRepository.findById(commentId).map(comment -> {
			this.commentRepository.delete(comment);
			return true;
		}).orElseThrow(()-> new ResourceNotFoundException("CommentId -> "+commentId+" not found"));
	}

	@Override
	public boolean deleteComments(Integer questionId) throws ResourceNotFoundException {
		if(!this.questionRepository.exists(questionId)) {
			throw new ResourceNotFoundException("QuestionId -> "+questionId+" not found");
		}
		return this.commentRepository.findByQuestionId(questionId).map(comment -> {
			this.commentRepository.delete(comment);
			return true;
		}).orElseThrow(()-> new ResourceNotFoundException("Comment not found"));
		
	}

}
