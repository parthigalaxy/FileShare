package com.stackroute.qna.resource;

import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.stackroute.qna.domain.User;
import com.stackroute.qna.exception.UserAlreadyExistException;
import com.stackroute.qna.exception.UserNotFoundException;
import com.stackroute.qna.exception.UserValidationException;
import com.stackroute.qna.service.SecurityTokenGenrator;
import com.stackroute.qna.service.UserService;


@CrossOrigin
@RestController
@EnableWebMvc
@RequestMapping("/user")
public class UserResource {
	
	private static final Logger logger = LoggerFactory.getLogger(UserResource.class);
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private SecurityTokenGenrator securityTokenGenrator;
	
	@PostMapping("/register")
	public @ResponseBody ResponseEntity<?> registerUser(@Valid @RequestBody final User user){
		logger.debug("UserResource > registerUser > start");
		ResponseEntity<?> responseEntity;
		try {
			userService.saveUser(user);
			responseEntity = new ResponseEntity<String>("{\"message\":\" User Registred Successfully \"}",HttpStatus.CREATED);
		} catch (UserAlreadyExistException|UserNotFoundException | UserValidationException e) {
			logger.error("UserResource > registerUser > UserAlreadyExistException|UserNotFoundException",e);
			responseEntity = new ResponseEntity<String>("{\"message\":\""+e.getMessage()+"\"}",HttpStatus.CONFLICT);
		} 
		logger.debug("UserResource > registerUser > end");
		return responseEntity;
	}
	
	@PostMapping("/login")
	public @ResponseBody ResponseEntity<?> loginUser(@RequestBody final User user){
		logger.debug("UserResource > loginUser > start");
		ResponseEntity<?> responseEntity;
		try {
			if(null == user || StringUtils.isEmpty(user.getEmailAddress()) || StringUtils.isEmpty(user.getPassword())) {
				throw new Exception("UserName or Password Cannot be Empty");
			}
			User userResp = userService.findByEmailAddressAndPassword(user.getEmailAddress(), user.getPassword());
			if(null == userResp) {
				throw new UserNotFoundException("User with given EmailAddress does not exists");
			}
			
			if(!userResp.getPassword().equals(user.getPassword())) {
				throw new Exception("Invalid login credential, Please check username and passsword");
			}
			
			Map<String, String> jwtTokenMap  = securityTokenGenrator.geneateToken(userResp);
			responseEntity = new ResponseEntity<Map<String, String>>(jwtTokenMap,HttpStatus.OK);
		} catch (Exception e) {
			logger.error("UserResource > registerUser > Exception",e);
			responseEntity = new ResponseEntity<String>("{\"message\":\""+e.getMessage()+"\"}",HttpStatus.UNAUTHORIZED);
		} 
		logger.debug("UserResource > loginUser > end");
		return responseEntity;
	}

}
