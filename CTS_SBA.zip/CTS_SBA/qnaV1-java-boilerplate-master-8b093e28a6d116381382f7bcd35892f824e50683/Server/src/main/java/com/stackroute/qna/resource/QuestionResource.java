package com.stackroute.qna.resource;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mysql.jdbc.StringUtils;
import com.stackroute.qna.domain.Question;
import com.stackroute.qna.exception.ResourceNotFoundException;
import com.stackroute.qna.service.QuestionService;

import io.jsonwebtoken.Jwts;

@CrossOrigin
@RestController
@RequestMapping("/api/question")
public class QuestionResource {
	
	private static final Logger logger = LoggerFactory.getLogger(QuestionResource.class);
	
	@Autowired
	private QuestionService questionService;
	
	@GetMapping("{topicId}")
	public @ResponseBody ResponseEntity<?> retrieveQuestions(@PathVariable("topicId") String topicId){
		logger.debug("QuestionResource > retrieveQuestions > topicId -> "+ topicId +" -> start");
		ResponseEntity<?> responseEntity;
		if(StringUtils.isStrictlyNumeric(topicId)) {
			Optional<List<Question>> QuestionO = this.questionService.retrieveQuestions(Integer.parseInt(topicId));
			responseEntity = new ResponseEntity<List<Question>>(QuestionO.orElse(null),HttpStatus.OK);
		}else {
			responseEntity = new ResponseEntity<String>("{\"message\":\"Invalid Request\"}",HttpStatus.BAD_REQUEST);
		}
		logger.debug("QuestionResource > retrieveQuestions > topicId -> "+ topicId +" -> end");
		return responseEntity;
	}
	
	@GetMapping("/get/{questionId}")
	public @ResponseBody ResponseEntity<?> retrieveQuestion(@PathVariable("questionId") Integer questionId){
		logger.debug("QuestionResource > retrieveQuestion > start");
		Question question = this.questionService.retrieveQuestion(questionId);
		ResponseEntity<?> responseEntity = new ResponseEntity<Question>(question,HttpStatus.OK);
		logger.debug("QuestionResource > retrieveQuestion > end");
		return responseEntity;
	}
	
	@PostMapping("{topicId}")
	public @ResponseBody ResponseEntity<?> postQuestion(@PathVariable("topicId") String topicId,@RequestBody final Question question, HttpServletRequest request, HttpServletResponse response){
		logger.debug("QuestionResource > postQuestion > start");
		ResponseEntity<?> responseEntity;
		try {
			if(StringUtils.isStrictlyNumeric(topicId)) {
				question.setPostedBy(this.retrieveUserEmail(request));
				this.questionService.postQuestion(Integer.parseInt(topicId), question);
				responseEntity = new ResponseEntity<String>("{\"message\":\" Question posted Successfully \"}",HttpStatus.CREATED);
			}else {
				responseEntity = new ResponseEntity<String>("{\"message\":\"Invalid Request\"}",HttpStatus.BAD_REQUEST);
			}
		} catch (ResourceNotFoundException e) {
			logger.error("QuestionResource > postQuestion > ResourceNotFoundException",e);
			responseEntity = new ResponseEntity<String>("{\"message\":\""+e.getMessage()+"\"}",HttpStatus.CONFLICT);
		} 
		logger.debug("QuestionResource > postQuestion > end");
		return responseEntity;
	}
	
	@DeleteMapping(path="/{topicId}/{questionId}")
	public @ResponseBody ResponseEntity<?> deleteQuestion(@PathVariable("topicId") int topicId,@PathVariable("questionId") int questionId){
		logger.debug("QuestionResource > deleteQuestion > start");
		ResponseEntity<?> responseEntity;
		try {
			this.questionService.deleteQuestion(topicId, questionId);
			responseEntity = new ResponseEntity<String>("{\"message\":\"Question Deleted Successfully \"}",HttpStatus.OK);
		} catch (ResourceNotFoundException e) {
			logger.error("QuestionResource > deleteQuestion > ResourceNotFoundException",e);
			responseEntity = new ResponseEntity<String>("{\"message\":\""+e.getMessage()+"\"}",HttpStatus.NOT_FOUND);
		}
		logger.debug("QuestionResource > deleteQuestion > end");
		return responseEntity;
	}
	
	private String retrieveUserEmail(HttpServletRequest request) {
		final String authHeader = request.getHeader("Authorization");
		final String token = authHeader.substring(7);
		return Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
	}


}
