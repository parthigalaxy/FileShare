package com.stackroute.qna.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.qna.domain.Topic;
import com.stackroute.qna.repository.TopicRepository;

@Service
public class TopicServiceImpl implements TopicService {

	private TopicRepository topicRepository;
	
	@Autowired
	public TopicServiceImpl(TopicRepository topicRepository) {
		super();
		this.topicRepository = topicRepository;
	}
	
	@Override
	public List<Topic> retrieveAllTopics() {
		return this.topicRepository.findAll();
	}

	@Override
	public Topic retrieveTopic(Integer topicId) {
		return this.topicRepository.findOne(topicId);
	}

}
