SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE tbl_topic;
SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO tbl_topic (title,description) VALUES ("Java","Java is a high-level programming language developed by Sun Microsystems. It was originally designed for developing programs for set-top boxes and handheld devices, but later became a popular choice for creating web applications.");
INSERT INTO tbl_topic (title,description) VALUES ("Angular","AngularJS is a structural framework for dynamic web apps. With AngularJS, designers can use HTML as the template language and it allows for the extension of HTML's syntax to convey the application's components effortlessly.");
INSERT INTO tbl_topic (title,description) VALUES ("NodeJs","Node.js is a platform built on Chrome's JavaScript runtime for easily building fast and scalable network applications. Node.js uses an event-driven, non-blocking I/O model that makes it lightweight and efficient, perfect for data-intensive real-time applications that run across distributed devices.");
INSERT INTO tbl_topic (title,description) VALUES ("MongoDB","MongoDB is an object-oriented, simple, dynamic, and scalable NoSQL database. It is based on the NoSQL document store model. The data objects are stored as separate documents inside a collection — instead of storing the data into the columns and rows of a traditional relational database.");
INSERT INTO tbl_topic (title,description) VALUES ("Python","Python is an interpreted, object-oriented programming language similar to PERL, that has gained popularity because of its clear syntax and readability.");
