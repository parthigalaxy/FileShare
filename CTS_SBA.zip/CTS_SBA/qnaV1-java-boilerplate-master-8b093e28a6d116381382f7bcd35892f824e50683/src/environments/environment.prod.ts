export const environment = {
  production: true,
  registerUserEndpoint: "http://localhost:8080/user/register",
  loginUserEndpoint: "http://localhost:8080/user/login",
  topicEndpoint: "http://localhost:8080/api/topic",
  questionEndpoint: "http://localhost:8080/api/question",
  commentEndpoint: "http://localhost:8080/api/comment"
};
