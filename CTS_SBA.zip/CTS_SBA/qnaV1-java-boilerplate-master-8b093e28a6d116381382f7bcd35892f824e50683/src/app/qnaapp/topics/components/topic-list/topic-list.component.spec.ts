import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { MatToolbarModule,MatToolbar} from "@angular/material/toolbar";
import { QnaserviceService } from '../../../../qnaapp/qnaservice/qnaservice.service';
import { QnaMatModule } from '../../../../qnaapp/qna-mat/qna-mat.module';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { Topic } from '../../../qnaservice/topic';
import { Question } from '../../../qnaservice/question';
import { TopicListComponent } from './topic-list.component';
import { TopicViewComponent } from '../topic-view/topic-view.component';

describe('TopicListComponent', () => {
  let component: TopicListComponent;
  let fixture: ComponentFixture<TopicListComponent>;

  class QnaserviceServiceStub{
    currentUser:any;
    constructor(){
    }

    retrieveTopic(credentials){
  
      let topic = new Topic();
      topic.id = '1';
      topic.title='java';
      return Observable.of(topic);
      
    }

    retrieveQuestions(topicId){
      let questions = new Array<Question>();
      return Observable.of(questions);
    }

  }

  class dummy{
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopicListComponent, TopicViewComponent ],
      imports:[FormsModule,HttpClientModule,QnaMatModule,
        BrowserAnimationsModule,RouterTestingModule.withRoutes([{path:'',component:dummy}])],
      providers:[{provide:QnaserviceService,useClass:QnaserviceServiceStub}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    location = TestBed.get(Location);
    fixture = TestBed.createComponent(TopicListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    fixture.debugElement.injector.get(QnaserviceService);
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
