import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { QnaMatModule } from '../../../../qnaapp/qna-mat/qna-mat.module';
import { TopicViewComponent } from './topic-view.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

describe('TopicViewComponent', () => {
  let component: TopicViewComponent;
  let fixture: ComponentFixture<TopicViewComponent>;
  let router: Router;
  let location: Location;

  class dummy{
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopicViewComponent ],
      imports:[QnaMatModule,RouterTestingModule.withRoutes([{path:'',component:dummy}])]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    router = TestBed.get(Router);
    fixture = TestBed.createComponent(TopicViewComponent);
    location = TestBed.get(Location);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
