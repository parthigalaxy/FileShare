import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { TopicDetailsComponent } from './topic-details.component';
import { QuestionListComponent } from '../../../questions/components/question-list/question-list.component';
import { QuestionviewComponent } from '../../../questions/components/questionview/questionview.component';
import { AskQuestionComponent } from '../../../questions/components/ask-question/ask-question.component';
import { QnaMatModule } from '../../../../qnaapp/qna-mat/qna-mat.module';
import { MatCardModule } from "@angular/material/card";
import { MatButtonModule } from "@angular/material/button";
import { MatSnackBarModule } from "@angular/material/snack-bar";
import { MatFormFieldModule, MatIconModule, MatInputModule } from "@angular/material";
import { QnaserviceService } from '../../../../qnaapp/qnaservice/qnaservice.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { Topic } from '../../../qnaservice/topic';
import { Question } from '../../../qnaservice/question';

describe('TopicDetailsComponent', () => {
  let component: TopicDetailsComponent;
  let fixture: ComponentFixture<TopicDetailsComponent>;
  let router: Router;
  let location: Location;

  class QnaserviceServiceStub{
    currentUser:any;
    constructor(){
    }

    retrieveTopic(credentials){
  
      let topic = new Topic();
      topic.id = '1';
      topic.title='java';
      return Observable.of(topic);
      
    }

    retrieveQuestions(topicId){
      let questions = new Array<Question>();
      return Observable.of(questions);
    }

  }
  class dummy{
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopicDetailsComponent,QuestionListComponent,AskQuestionComponent,QuestionviewComponent ],
      imports:[FormsModule,HttpClientModule,MatFormFieldModule, MatSnackBarModule, MatIconModule, MatInputModule,
        BrowserAnimationsModule,MatCardModule,QnaMatModule,RouterTestingModule.withRoutes([{path:'',component:dummy}])],
      providers:[{provide:QnaserviceService,useClass:QnaserviceServiceStub}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    router = TestBed.get(Router);
    location = TestBed.get(Location);
    fixture = TestBed.createComponent(TopicDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    fixture.debugElement.injector.get(QnaserviceService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
