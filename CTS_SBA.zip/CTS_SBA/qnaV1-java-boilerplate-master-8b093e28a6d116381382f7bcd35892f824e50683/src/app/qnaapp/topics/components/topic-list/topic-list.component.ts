import { Component, OnInit } from '@angular/core';
import { QnaserviceService } from '../../../qnaservice/qnaservice.service';
import { Topic } from '../../../qnaservice/topic';

@Component({
  selector: 'qna-topic-list',
  templateUrl: './topic-list.component.html',
  styleUrls: ['./topic-list.component.css']
})
export class TopicListComponent implements OnInit {

  topics:Array<Topic>;

  constructor(private qnaService:QnaserviceService) { }

  ngOnInit() {
    this.topics = this.prepareTopics();
  }

  prepareTopics():Array<Topic>{
    let topicsl = new Array<Topic>();
    this.qnaService.retrieveTopics().subscribe(topics => {
      topicsl.push(...topics);
    });
    return topicsl;
   }
   
}
