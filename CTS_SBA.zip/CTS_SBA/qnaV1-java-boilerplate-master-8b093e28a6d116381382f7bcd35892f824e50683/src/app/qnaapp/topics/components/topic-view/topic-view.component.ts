import { Component, OnInit,Input } from '@angular/core';
import { Topic } from '../../../qnaservice/topic';

@Component({
  selector: 'qna-topic-view',
  templateUrl: './topic-view.component.html',
  styleUrls: ['./topic-view.component.css']
})
export class TopicViewComponent implements OnInit {

  @Input()
  topic:Topic;

  constructor() { }

  ngOnInit() {  }

}
