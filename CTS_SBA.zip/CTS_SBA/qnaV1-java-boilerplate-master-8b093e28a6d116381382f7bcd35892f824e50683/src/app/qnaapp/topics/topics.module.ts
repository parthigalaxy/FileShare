import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TopicListComponent } from './components/topic-list/topic-list.component';
import { TopicViewComponent } from './components/topic-view/topic-view.component';
import { TopicDetailsComponent } from './components/topic-details/topic-details.component';
import { QnaMatModule } from '../../qnaapp/qna-mat/qna-mat.module';
import { QnaRoutesModule } from '../../qnaapp/qna-routes/qna-routes.module';
import { QuestionsModule } from '../../qnaapp/questions/questions.module';

@NgModule({
  imports: [
    CommonModule,
    QnaMatModule,
    QnaRoutesModule,
    QuestionsModule
  ],
  declarations: [TopicListComponent, TopicViewComponent, TopicDetailsComponent],
  exports:[TopicListComponent, TopicViewComponent, TopicDetailsComponent]
})
export class TopicsModule { }
