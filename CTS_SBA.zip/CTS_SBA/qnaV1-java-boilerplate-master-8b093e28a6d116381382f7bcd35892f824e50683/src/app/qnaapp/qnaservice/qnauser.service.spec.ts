import { TestBed, inject, fakeAsync } from '@angular/core/testing';
import { HttpClientModule, HttpClient, HttpEvent, HttpEventType } from '@angular/common/http'
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing'
import { Observable } from 'rxjs/Observable';
import { QnauserService } from './qnauser.service';

const testConfig = {
  addUser:{
    positive:{
      emailAddress:"test1@test.com",
      firstName:"test",
      lastName:"test",
      password:"test1",
      confirmPassword:"test1"
    }
  },
  loginUser:{
    positive:{
      emailAddress:"test1@test.com",
      password:"test1"
    }
  }
}

describe('QnauserService', () => {
  let qnauserService:QnauserService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientModule,HttpClientTestingModule],
      providers: [QnauserService]
    });
    qnauserService = TestBed.get(QnauserService);
  });

  it('should be created', inject([QnauserService], (service: QnauserService) => {
    expect(service).toBeTruthy();
  }));

  it('should register user data',fakeAsync(() => {
    let data = testConfig.addUser.positive;
    inject([QnauserService,HttpTestingController], (backend: HttpTestingController) => {
      const mockReq = backend.expectOne(qnauserService.registerUrl);
      expect(mockReq.request.url).toEqual(qnauserService.registerUrl,'register url should match with json server api');
      expect(mockReq.request.method).toBe('POST','should handle requested method type');
      mockReq.flush(data);
      backend.verify();
    })

    qnauserService.registerUser(data).subscribe((res:any)=>{
      expect(res).toBeDefined();
      expect(res._body).toBe(data,"data should be same");
    });

  }));

  it('should login user',fakeAsync(() => {
    let data = testConfig.loginUser.positive;
    inject([QnauserService,HttpTestingController], (backend: HttpTestingController) => {
      const mockReq = backend.expectOne(qnauserService.loginUrl);
      expect(mockReq.request.url).toEqual(qnauserService.loginUrl,'login url should match with json server api');
      expect(mockReq.request.method).toBe('POST','should handle requested method type');
      mockReq.flush(data);
      backend.verify();
    })

    qnauserService.loginUser(data).subscribe((res:any)=>{
      expect(res).toBeDefined();
      expect(res._body).toBe(data,"data should be same");
    });

  }));

});
