export class User {

    id?:string;
    firstName?:string;
    lastName?:string;
    emailAddress?:string;
    password?:string;
    confirmPassword?:string;
    createdDate?:string;

    constructor(){        
    }
    
}
