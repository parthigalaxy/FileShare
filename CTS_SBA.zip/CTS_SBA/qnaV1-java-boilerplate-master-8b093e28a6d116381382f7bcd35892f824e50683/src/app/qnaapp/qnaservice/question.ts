import { Comment } from './comment';
export class Question {

    id?:string;
    question?:string;
    topicId?:string;
    topictitle?:string;
    postedDate?:Date;
    comments?:Array<Comment>;
    postedBy?:string;
    constructor(){     
        this.comments=Array<Comment>();   
    }

}
