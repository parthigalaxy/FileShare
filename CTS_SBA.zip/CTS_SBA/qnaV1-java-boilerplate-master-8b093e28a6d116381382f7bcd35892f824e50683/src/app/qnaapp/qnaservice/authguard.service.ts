import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { CanActivate } from '@angular/router/src/interfaces'
import { QnauserService } from './qnauser.service';

@Injectable()
export class AuthguardService {

  constructor(private qnauserService:QnauserService,private router:Router) { }

  canActivate(){
    if(!this.qnauserService.isTokenExpired()){
      console.log("In AuthguardService canActivate");
      return true;
    }
    this.router.navigate(['/login']);
    return false;
  }

}
