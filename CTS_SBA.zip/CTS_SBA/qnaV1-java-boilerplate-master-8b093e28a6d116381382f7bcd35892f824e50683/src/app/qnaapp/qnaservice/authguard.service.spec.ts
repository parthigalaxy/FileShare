import { TestBed, inject } from '@angular/core/testing';

import { AuthguardService } from './authguard.service';

import { QnauserService } from '../qnaservice/qnauser.service';
import { RouterTestingModule } from '@angular/router/testing'

describe('AuthguardService', () => {

  class QnauserServiceStub{
    currentUser:any;
    constructor(){
    }

  }

  class dummy{
  }


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthguardService,{provide:QnauserService,useClass:QnauserServiceStub}],
      imports:[RouterTestingModule.withRoutes([{path:'',component:dummy}])]
    });
  });

  it('should be created', inject([AuthguardService], (service: AuthguardService) => {
    expect(service).toBeTruthy();
  }));
});
