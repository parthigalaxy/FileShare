export class Topic {

    id?:string;
    title?:string;
    description?:string;

    constructor(){        
    }

}
