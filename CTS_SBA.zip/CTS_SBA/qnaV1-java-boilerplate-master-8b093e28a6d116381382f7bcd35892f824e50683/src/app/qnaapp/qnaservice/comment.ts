export class Comment {
    id?:string;
    comment?:string;
    questionId?:string;
    question?:string;
    commentDate?:string;
    postedBy?:string;
    constructor(){        
    }
}
