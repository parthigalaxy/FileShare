import { TestBed, inject } from '@angular/core/testing';
import { HttpClientModule, HttpClient, HttpEvent, HttpEventType } from '@angular/common/http'
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing'
import { QnaserviceService } from './qnaservice.service';

describe('QnaserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientModule,HttpClientTestingModule],
      providers: [QnaserviceService]
    });
  });

  it('should be created', inject([QnaserviceService], (service: QnaserviceService) => {
    expect(service).toBeTruthy();
  }));
});
