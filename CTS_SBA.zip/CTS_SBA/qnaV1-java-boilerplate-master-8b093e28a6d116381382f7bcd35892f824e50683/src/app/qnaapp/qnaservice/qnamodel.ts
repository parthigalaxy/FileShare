export class Qnamodel {
}
