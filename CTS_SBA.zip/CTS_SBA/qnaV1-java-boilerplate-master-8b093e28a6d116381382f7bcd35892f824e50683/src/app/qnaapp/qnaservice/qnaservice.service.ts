import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import {map} from 'rxjs/operators/map';
import { Observable } from 'rxjs/Observable';
import { retry } from 'rxjs/operators';
import { Question } from './question';
import { Topic } from './topic';
import { Comment } from './comment';
import { environment } from '../../../environments/environment';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class QnaserviceService {

  topicUrl:string = environment.topicEndpoint;
  questionUrl:string = environment.questionEndpoint;
  commentUrl:string = environment.commentEndpoint;

  constructor(private http:HttpClient) { }

  retrieveTopics():Observable<Array<Topic>>{
    return this.http.get(this.topicUrl).pipe(
      map(this.retrieveResult)
    );
  }

  retrieveTopic(topicId:string):Observable<Topic>{
    return this.http.get(`${this.topicUrl}/${topicId}`).pipe(
      map(this.retrieveResult)
    );
  }

  retrieveResult(response){
    console.log(response);
    return response;
  }

  retrieveQuestions(topic:string):Observable<Array<Question>>{
    let questionUrl = `${this.questionUrl}/${topic}`;
    return this.http.get(questionUrl).pipe(map(this.retrieveResult));
  }

  retrieveQuestion(questionId:string):Observable<Question>{
    let questionUrl = `${this.questionUrl}/get/${questionId}`;
    return this.http.get(questionUrl).pipe(map(this.retrieveResult));
  }

  postNewQuestion(topicId:string,question:Question){
    let questionUrl = `${this.questionUrl}/${topicId}`;
    return this.http.post(questionUrl,question,{responseType:'json'});
  }

  deleteQuestion(topicId:string,questionId:string){
    let questionUrl = `${this.questionUrl}/${topicId}/${questionId}`;
    return this.http.delete(questionUrl,{responseType:'json'});
  }

  retrieveComments(questionId:string):Observable<Array<Comment>>{
    let commentUrl = `${this.commentUrl}/${questionId}`;
    return this.http.get(commentUrl).pipe(map(this.retrieveResult));
  }

  postNewComment(topicId:string,comment:Comment){
    let commentUrl = `${this.commentUrl}/${topicId}`;
    return this.http.post(commentUrl,comment,{responseType:'json'});
  }

  deleteComment(questionId:string,commentId:string){
    let commentUrl = `${this.commentUrl}/${questionId}/${commentId}`;
    return this.http.delete(commentUrl,{responseType:'json'});
  }

}
