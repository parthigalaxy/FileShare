import { Injectable,Injector } from '@angular/core';

import { QnauserService } from './qnauser.service';
import { HttpRequest,
         HttpHandler,
         HttpEvent,
         HttpInterceptor
        } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class InterceptorService implements HttpInterceptor {

  private qnauserService: QnauserService;

  constructor(private injector: Injector) {}

  intercept(request:HttpRequest<any>,next:HttpHandler):Observable<HttpEvent<any>>{
    this.qnauserService = this.injector.get(QnauserService);
    console.log("InterceptorService -> called");
    request = request.clone({
      setHeaders:{
        Authorization : `Bearer ${this.qnauserService.getToken()}`
      }
    });
    return next.handle(request);
  }

}
