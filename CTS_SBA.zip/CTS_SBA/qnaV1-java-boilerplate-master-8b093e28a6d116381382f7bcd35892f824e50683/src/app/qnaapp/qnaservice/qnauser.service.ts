import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { User } from './user';
import {map} from 'rxjs/operators/map';
import { Observable } from 'rxjs/Observable';
import { retry } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

import * as jwt_decode from 'jwt-decode';
export const TOKEN_NAME = "jwt_token";

@Injectable()
export class QnauserService {

  registerUrl:string = environment.registerUserEndpoint;
  loginUrl:string = environment.loginUserEndpoint;
  
  constructor(private http:HttpClient) { }

  registerUser(user:User){
    return this.http.post(this.registerUrl,user,{responseType:'json'});
  }

  loginUser(user:User){
    return this.http.post(this.loginUrl,user);
  }

  setToken(token:string){
    return localStorage.setItem(TOKEN_NAME,token);
  }

  getToken(){
    return localStorage.getItem(TOKEN_NAME);
  }

  deleteToken(){
    return localStorage.removeItem(TOKEN_NAME);
  }

  getTokenExpirationDate(token:string):Date{
    const decode = jwt_decode(token);
    if(decode.exp === undefined) return null;
    const date = new Date();
    date.setUTCSeconds(decode.exp);
    return date;
  }

  isTokenExpired(token?:string):boolean{
    if(!token) token = this.getToken();
    if(!token) return true;
    const date = this.getTokenExpirationDate(token);
    if(date === undefined || date ===null) return false;
    return !(date.valueOf() > new Date().valueOf());
  }

}
