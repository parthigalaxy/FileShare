import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import { QnauserService } from '../../../qnaservice/qnauser.service';
import { User } from '../../../qnaservice/user';
import { Router } from '@angular/router';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing'

import { MatButtonModule } from "@angular/material/button";
import { MatSnackBarModule } from "@angular/material/snack-bar";
import { MatFormFieldModule, MatIconModule, MatInputModule } from "@angular/material";
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

const testConfig = {
  userData:{
    positive:{
      emailAddress:"test1@test.com",
      firstName:"test",
      lastName:"test",
      password:"test1",
      confirmPassword:"test1"
    }
  }
}

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let qnauserService:QnauserService;
  let spyUser:any;
  let router: Router;
  let location: Location;

  class QnauserServiceStub{
    currentUser:any;
    constructor(){
    }

    loginUser(credentials){
      if(credentials.emailAddress == testConfig.userData.positive.emailAddress){
        console.log("data :",this.currentUser);
        return Observable.of(credentials.userId);
      }
      return Observable.of(false);
    }

  }

  class dummy{
  }
  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports:[FormsModule,HttpClientModule,MatFormFieldModule, MatSnackBarModule, MatIconModule, MatInputModule,
        BrowserAnimationsModule,RouterTestingModule.withRoutes([{path:'',component:dummy}])],
      providers:[{provide:QnauserService,useClass:QnauserServiceStub}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    router = TestBed.get(Router);
    fixture = TestBed.createComponent(LoginComponent);
    location = TestBed.get(Location);
    component = fixture.componentInstance;
    fixture.detectChanges();
    fixture.debugElement.injector.get(QnauserService);
  });

  it('should create', async() => {
    const component = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  });

  it('should two input box for emailAddress and password',() => {
    const emailAddress = fixture.debugElement.query(By.css('.emailAddress'));
    const password = fixture.debugElement.query(By.css('.password'));
    const loginUser = fixture.debugElement.query(By.css('.login-user'));
    const registerUser = fixture.debugElement.query(By.css('.register-user'));
    
    let emailAddressInput = emailAddress.nativeElement;
    let passwordInput = password.nativeElement;
    let loginUserButton = loginUser.nativeElement;
    let registerUserButton = registerUser.nativeElement;

    expect(emailAddressInput).toBeTruthy();
    expect(passwordInput).toBeTruthy();
    expect(loginUserButton).toBeTruthy();
    expect(registerUserButton).toBeTruthy();

  });

  it('should redirect to Login if register successfull',() => {
    const emailAddress = fixture.debugElement.query(By.css('.emailAddress'));
    const password = fixture.debugElement.query(By.css('.password'));
    const loginUser = fixture.debugElement.query(By.css('.login-user'));
    const registerUser = fixture.debugElement.query(By.css('.register-user'));
    
    let emailAddressInput = emailAddress.nativeElement;
    let passwordInput = password.nativeElement;
    let loginUserButton = loginUser.nativeElement;
    let registerUserButton = registerUser.nativeElement;

    fixture.detectChanges();
    fixture.whenStable().then(()=>{
      emailAddressInput.value="test1@test.com";
      passwordInput.value="test1";
      emailAddressInput.dispatchEvent(new Event('input'));
      passwordInput.dispatchEvent(new Event('input'));
      loginUserButton.click();
    }).then(()=>{
      expect(location.path()).toBe('');
    });

  });

});