import { Component, OnInit } from '@angular/core';
import { QnauserService } from '../../../qnaservice/qnauser.service';
import { User } from '../../../qnaservice/user';
import { Router } from '@angular/router';
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
  selector: 'qna-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  newUser:User;
  registerError:boolean;
  registerErrorMessage:string;
  constructor(private qnauserService: QnauserService,private router:Router,private snackBar:MatSnackBar) { 
    this.newUser = new User();
  }

  ngOnInit() {
    this.registerError=false;
    this.registerErrorMessage="";
  }

  registerUser(status){
    if(!status){
      return false;
    }
    console.log("New User : "+status+" - "+JSON.stringify(this.newUser));
    this.qnauserService.registerUser(this.newUser).subscribe((data)=>{
      console.log("userData", data);
      this.snackBar.open("User registred successfully !","",{duration:1000});
      this.router.navigate(['/login']);
    },
    (error) => {
      this.registerError=true;
      this.registerErrorMessage=error.error.message;
      console.log("Error while saving !", error);
      
    }
  );
  }

  resetInput(){
    this.newUser = new User();
  }
}
