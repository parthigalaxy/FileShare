import { Component, OnInit } from '@angular/core';
import { QnauserService } from '../../../qnaservice/qnauser.service';
import { User } from '../../../qnaservice/user';
import { Router } from '@angular/router';
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
  selector: 'qna-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  newUser:User;
  loginError:boolean;

  constructor(private qnauserService: QnauserService,private router:Router,private snackBar:MatSnackBar) { }

  ngOnInit() {
    this.newUser = new User();
    this.loginError= false;
  }

  loginUser(){
    console.log("New User : "+JSON.stringify(this.newUser));
    this.qnauserService.loginUser(this.newUser).subscribe((data)=>{
      console.log("userData", data);
      if(data['token']){
        this.qnauserService.setToken(data['token']);
        this.snackBar.open("User login success!","",{duration:1000});
        this.router.navigate(['/topics']);
      }
    },
    (error) => {
      console.log("Error while login !", JSON.stringify(error));
      this.loginError= true;
    });
  }


}
