import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing'
import { MatToolbarModule,MatToolbar} from "@angular/material/toolbar";
import { QnauserService } from '../../../../qnaapp/qnaservice/qnauser.service';
import { QnaMatModule } from '../../../../qnaapp/qna-mat/qna-mat.module';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { RegisterComponent } from './register.component';

describe('RegisterComponent', () => {

  class QnauserServiceStub{
    currentUser:any;
    constructor(){
    }

  }

  class dummy{
  }

  let component: RegisterComponent;
  let fixture: ComponentFixture<RegisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterComponent ],
      imports:[FormsModule,HttpClientModule,QnaMatModule,
        BrowserAnimationsModule,RouterTestingModule.withRoutes([{path:'',component:dummy}])],
      providers:[{provide:QnauserService,useClass:QnauserServiceStub}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
