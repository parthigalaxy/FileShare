import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes} from '@angular/router';

import { TopicListComponent } from '../topics/components/topic-list/topic-list.component';
import { TopicDetailsComponent } from '../topics/components/topic-details/topic-details.component';
import { CommentviewComponent } from '../questions/components/commentview/commentview.component';
import { LoginComponent } from '../qna-user/components/login/login.component';
import { RegisterComponent } from '../qna-user/components/register/register.component';
import { AuthguardService } from '../qnaservice/authguard.service';

const qna_routes:Routes = [
  {
    path:"",
    redirectTo:"/login",
    pathMatch:"full",
  },
  {
    path:"login",
    component:LoginComponent,
    pathMatch:"full",
  },
  {
    path:"register",
    component:RegisterComponent,
    pathMatch:"full",
  },
  {
    path:"topics",
    component:TopicListComponent,
    canActivate:[AuthguardService],
    pathMatch:"full",
  },
  {
    path:"topic-details/:topic",
    component:TopicDetailsComponent,
    canActivate:[AuthguardService],
  },
  {
    path:"question-details/:questionId",
    component:CommentviewComponent,
    canActivate:[AuthguardService],
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(qna_routes)
  ],
  declarations: [],
  exports:[RouterModule]
})
export class QnaRoutesModule { }
