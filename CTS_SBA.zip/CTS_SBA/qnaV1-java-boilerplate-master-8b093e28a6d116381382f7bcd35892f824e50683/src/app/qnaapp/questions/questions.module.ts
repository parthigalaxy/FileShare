import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { QuestionListComponent } from './components/question-list/question-list.component';
import { QuestionviewComponent } from './components/questionview/questionview.component';
import { AskQuestionComponent } from './components/ask-question/ask-question.component';
import { CommentviewComponent } from './components/commentview/commentview.component';
import { PostcommentComponent } from './components/postcomment/postcomment.component';
import { QnaMatModule } from '../../qnaapp/qna-mat/qna-mat.module';
import { QnaRoutesModule } from '../../qnaapp/qna-routes/qna-routes.module';

@NgModule({
  imports: [
    CommonModule,
    QnaMatModule,
    QnaRoutesModule,
    FormsModule
  ],
  declarations: [QuestionListComponent, QuestionviewComponent, AskQuestionComponent, CommentviewComponent, PostcommentComponent],
  exports:[QuestionListComponent, QuestionviewComponent, AskQuestionComponent, CommentviewComponent, PostcommentComponent]
})
export class QuestionsModule { }
