import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';
import { Question } from '../../../qnaservice/question';
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
  selector: 'qna-ask-question',
  templateUrl: './ask-question.component.html',
  styleUrls: ['./ask-question.component.css']
})
export class AskQuestionComponent implements OnInit {

  @Input()
  question:Question;

  @Output()
  aksquestionEmi : EventEmitter<Question>= new EventEmitter();

  aksquestion:Question;

  constructor(private snackBar:MatSnackBar) { }

  ngOnInit() {
    this.aksquestion = this.prepareNewQuestion();
  }

  prepareNewQuestion():Question{
    let question = new Question();
    question.topicId = this.question.topicId;
    return question;
  }

  resetInput(){
    this.aksquestion = this.prepareNewQuestion();
  }

  postNewQuestion(status){
    if(!status){
      return false;
    }
    this.aksquestionEmi.emit(this.aksquestion);
  }

}
