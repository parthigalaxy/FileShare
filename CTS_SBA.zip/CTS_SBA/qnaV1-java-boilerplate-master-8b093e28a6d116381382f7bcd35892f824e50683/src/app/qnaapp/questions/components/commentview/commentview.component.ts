import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Comment } from '../../../qnaservice/comment';
import { QnaserviceService } from '../../../qnaservice/qnaservice.service';
import { MatSnackBar } from "@angular/material/snack-bar";
import { Question } from '../../../qnaservice/question';

@Component({
  selector: 'qna-commentview',
  templateUrl: './commentview.component.html',
  styleUrls: ['./commentview.component.css']
})
export class CommentviewComponent implements OnInit {

  questionId:string;

  comments:Array<Comment>;

  question:Question;

  comment:Comment;

  constructor(private route:ActivatedRoute,private qnaService:QnaserviceService,private location:Location,private snackBar:MatSnackBar) { }

  ngOnInit() {
    this.comments = new Array<Comment>();
    this.question = new Question();
    this.questionId = this.route.snapshot.paramMap.get('questionId');
    this.refreshComments();
    this.qnaService.retrieveQuestion(this.questionId).subscribe(question => {
      this.question = question;
    });
    this.comment = new Comment();
    this.comment.questionId = this.questionId;
  }

  refreshComments(){
    this.comments = new Array<Comment>();
    this.qnaService.retrieveComments(this.questionId).subscribe(comments => {
      this.comments.push(...comments);
    });
  }

  bcakToTopic(){
    this.location.back();
  }

  postcomment(comment:Comment){
    this.qnaService.postNewComment(this.questionId,comment).subscribe(comment =>{
      this.snackBar.open("Comment posted successfully!","",{duration:1000});
      this.refreshComments();
    },error =>{
      this.snackBar.open("Error while posting question !","Close",{duration:9000});
    });
  }

  deleteComment(comment:Comment){
    this.qnaService.deleteComment(this.questionId,comment.id).subscribe(question =>{
      this.snackBar.open("Comment Deleted successfully!","",{duration:1000});
      this.refreshComments();
    },error =>{
      this.snackBar.open("Error while Deleted Comment !","Close",{duration:9000});
    });
  }


}
