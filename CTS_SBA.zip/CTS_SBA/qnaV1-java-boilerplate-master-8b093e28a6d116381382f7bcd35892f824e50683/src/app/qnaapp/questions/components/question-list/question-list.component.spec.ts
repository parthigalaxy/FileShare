import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing'
import { MatToolbarModule,MatToolbar} from "@angular/material/toolbar";
import { QnaserviceService } from '../../../../qnaapp/qnaservice/qnaservice.service';
import { QnaMatModule } from '../../../../qnaapp/qna-mat/qna-mat.module';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { Topic } from '../../../qnaservice/topic';
import { Question } from '../../../qnaservice/question';
import { QuestionListComponent } from './question-list.component';
import { QuestionviewComponent } from '../questionview/questionview.component';
import { AskQuestionComponent } from '../ask-question/ask-question.component';

describe('QuestionListComponent', () => {

  class QnaserviceServiceStub{
    currentUser:any;
    constructor(){
    }

    retrieveTopic(credentials){
  
      let topic = new Topic();
      topic.id = '1';
      topic.title='java';
      return Observable.of(topic);
      
    }

    retrieveQuestions(topicId){
      let questions = new Array<Question>();
      return Observable.of(questions);
    }

  }

  class dummy{
  }

  let component: QuestionListComponent;
  let fixture: ComponentFixture<QuestionListComponent>;
  let location: Location;
  let qnaService:QnaserviceService
  
  beforeEach(async(() => {
    let question:Question;

    TestBed.configureTestingModule({
      declarations: [ QuestionListComponent,AskQuestionComponent,QuestionviewComponent ],
      imports:[FormsModule,HttpClientModule,QnaMatModule,
        BrowserAnimationsModule,RouterTestingModule.withRoutes([{path:'',component:dummy}])],
      providers:[{provide:QnaserviceService,useClass:QnaserviceServiceStub}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionListComponent);
    location = TestBed.get(Location);
    component = fixture.componentInstance;
    let question = new  Question();
    fixture.detectChanges();
    fixture.debugElement.injector.get(QnaserviceService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
