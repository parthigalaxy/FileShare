// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { Location } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { By } from '@angular/platform-browser';
// import { HttpClientModule } from '@angular/common/http';
// import { RouterTestingModule } from '@angular/router/testing'
// import { MatToolbarModule,MatToolbar} from "@angular/material/toolbar";

// import { QnaserviceService } from '../../../../qnaapp/qnaservice/qnaservice.service';
// import { QnaMatModule } from '../../../../qnaapp/qna-mat/qna-mat.module';
// import { Observable } from 'rxjs/Observable';
// import 'rxjs/add/observable/of';

// import { PostcommentComponent } from './postcomment.component';

// describe('PostcommentComponent', () => {
//   let component: PostcommentComponent;
//   let fixture: ComponentFixture<PostcommentComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PostcommentComponent ],
//       imports:[FormsModule,HttpClientModule,QnaMatModule]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PostcommentComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
