import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';
import { Question } from '../../../qnaservice/question';
@Component({
  selector: 'qna-questionview',
  templateUrl: './questionview.component.html',
  styleUrls: ['./questionview.component.css']
})
export class QuestionviewComponent implements OnInit {

  @Input()
  question:Question;

  @Output()
  deleteQuestionEmi : EventEmitter<Question>= new EventEmitter();


  constructor() { }

  ngOnInit() {
  }

  deleteQuestion(deleteQuestion:Question){
    this.deleteQuestionEmi.emit(deleteQuestion);
  }

}
