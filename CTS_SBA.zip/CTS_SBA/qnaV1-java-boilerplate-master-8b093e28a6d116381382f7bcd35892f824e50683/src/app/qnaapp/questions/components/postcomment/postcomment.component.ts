import { Component, OnInit, Input,Output,EventEmitter } from '@angular/core';
import { Comment } from '../../../qnaservice/comment';

@Component({
  selector: 'qna-postcomment',
  templateUrl: './postcomment.component.html',
  styleUrls: ['./postcomment.component.css']
})
export class PostcommentComponent implements OnInit {

  @Input()
  comment:Comment;

  @Output()
  postcommentEmi : EventEmitter<Comment>= new EventEmitter();

  postcomment:Comment;

  constructor() { }

  ngOnInit() {
    this.postcomment = this.prepareNewComment();
  }

  prepareNewComment():Comment{
    let comment = new Comment();
    comment.questionId = this.comment.questionId;
    return comment;
  }

  resetInput(){
    this.postcomment = this.prepareNewComment();
  }

  postNewComment(status){
    if(!status){
      return false;
    }
    this.postcommentEmi.emit(this.postcomment);
  }
  
}
