import { Component, OnInit, Input } from '@angular/core';
import { Location } from '@angular/common';
import { QnaserviceService } from '../../../qnaservice/qnaservice.service';
import { Question } from '../../../qnaservice/question';
import { Topic } from '../../../qnaservice/topic';
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
  selector: 'qna-question-list',
  templateUrl: './question-list.component.html',
  styleUrls: ['./question-list.component.css']
})
export class QuestionListComponent implements OnInit {

  @Input()
  topicId:string;

  topic:Topic;

  questions:Array<Question>;

  question:Question;

  constructor(private qnaService:QnaserviceService,private location:Location,private snackBar:MatSnackBar) { }

  ngOnInit() {
    this.questions = new Array<Question>();
    this.topic = new Topic();
    this.refreshQuestion();

    this.qnaService.retrieveTopic(this.topicId).subscribe(topic => {
      this.topic = topic;
    });

    this.question = new Question();
    this.question.topicId = this.topicId;
  }

  refreshQuestion(){
    this.questions = new Array<Question>();
    this.qnaService.retrieveQuestions(this.topicId).subscribe(questions => {
      this.questions.push(...questions);
    });
  }

  bcakToTopic(){
    this.location.back();
  }

  postquestion(question:Question){
    this.qnaService.postNewQuestion(this.topicId,question).subscribe(question =>{
      this.snackBar.open("Question posted successfully!","",{duration:1000});
      this.refreshQuestion();
    },error =>{
      this.snackBar.open("Error while posting question !","Close",{duration:9000});
    });
  }

  deleteQuestion(question:Question){
    this.qnaService.deleteQuestion(this.topicId,question.id).subscribe(question =>{
      this.snackBar.open("Question Deleted successfully!","",{duration:1000});
      this.refreshQuestion();
    },error =>{
      this.snackBar.open("Error while Deleted question !","Close",{duration:9000});
    });
  }
  
}
