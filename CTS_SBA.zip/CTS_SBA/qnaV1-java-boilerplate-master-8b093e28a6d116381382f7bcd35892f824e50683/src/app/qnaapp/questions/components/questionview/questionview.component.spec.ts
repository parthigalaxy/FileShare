import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { QnaMatModule } from '../../../../qnaapp/qna-mat/qna-mat.module';
import { QuestionviewComponent } from './questionview.component';
import { RouterTestingModule } from '@angular/router/testing'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

describe('QuestionviewComponent', () => {
  let component: QuestionviewComponent;
  let fixture: ComponentFixture<QuestionviewComponent>;
  let router: Router;
  let location: Location;

  class dummy{
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuestionviewComponent ],
      imports:[QnaMatModule,BrowserAnimationsModule,RouterTestingModule.withRoutes([{path:'',component:dummy}])]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    router = TestBed.get(Router);
    fixture = TestBed.createComponent(QuestionviewComponent);
    location = TestBed.get(Location);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
