import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { QnauserService } from './qnaapp/qnaservice/qnauser.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'QnAApp';

  constructor(private qnauserService:QnauserService,private router:Router){}

  isUserLogedIn():boolean{
    if(this.qnauserService.getToken()){
      return true;
    }
    return false;
  }

  logout(){
    this.qnauserService.deleteToken();
    this.router.navigate(['/login']);
  }

}
