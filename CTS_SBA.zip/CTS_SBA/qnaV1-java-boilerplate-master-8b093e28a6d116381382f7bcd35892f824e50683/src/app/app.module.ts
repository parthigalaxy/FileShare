import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { QnaMatModule } from './qnaapp/qna-mat/qna-mat.module';
import { QuestionsModule } from './qnaapp/questions/questions.module';
import { TopicsModule } from './qnaapp/topics/topics.module';
import { QnaRoutesModule } from './qnaapp/qna-routes/qna-routes.module';
import { QnaUserModule } from './qnaapp/qna-user/qna-user.module';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpClientModule } from '@angular/common/http';

import { QnaserviceService } from './qnaapp/qnaservice/qnaservice.service';
import { QnauserService } from './qnaapp/qnaservice/qnauser.service';
import { AuthguardService } from './qnaapp/qnaservice/authguard.service';
import { InterceptorService } from './qnaapp/qnaservice/interceptor.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

const app_routes:Routes = [
  {
    path:"",
    redirectTo:"/login",
    pathMatch:"full"
  }
];

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    QnaMatModule,
    QuestionsModule,
    TopicsModule,
    RouterModule.forRoot(app_routes),
    QnaRoutesModule,
    QnaUserModule,
    HttpClientModule,
    BrowserAnimationsModule
  ],
  providers: [QnaserviceService,QnauserService,AuthguardService,{
    provide:HTTP_INTERCEPTORS,
    useClass:InterceptorService,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
