import { AppPage } from "./app.po";
import { browser, by, element } from 'protractor';
import { protractor } from 'protractor/built/ptor';
import { async } from '@angular/core/testing';

describe("question-n-answers App", () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it("should display title", () => {
    page.navigateTo();
    expect(browser.getTitle()).toEqual("QnAApp");
  });

  it('render page should be login',()=>{
    expect(browser.getCurrentUrl()).toContain('/login');
  });

  it('should be redirect to /register route',()=>{
    browser.element(by.css(".register-user")).click();
    expect(browser.getCurrentUrl()).toContain('/register');
  });

  it('should be able to register',()=>{
    browser.element(by.id("firstName")).sendKeys("test");
    browser.element(by.id("lastName")).sendKeys("test");
    browser.element(by.id("emailAddress")).sendKeys("test1@test.com");
    browser.element(by.id("password")).sendKeys("test1");
    browser.element(by.id("confirmPassword")).sendKeys("test1");
    browser.element(by.css(".register-user")).click();
    expect(browser.getCurrentUrl()).toContain('/login');
  });

  it('should be able to login user and navigaet to topics page',()=>{
    browser.element(by.id("emailAddress")).sendKeys("test1@test.com");
    browser.element(by.id("password")).sendKeys("test1");
    browser.element(by.css(".login-user")).click();
    expect(browser.getCurrentUrl()).toContain('/topics');
  });

  it('shuld be able to view topic details',()=>{
    browser.element(by.css(".view-topic-details")).click();
    expect(browser.getCurrentUrl()).toContain('/topic-details');
  });

  it('shuld be able to ask a question',()=>{
    browser.element(by.id("question-field")).sendKeys("What is java?");
    browser.element(by.id("question-button")).click();
    expect(browser.getCurrentUrl()).toContain('/topic-details');
  });

  it('shuld be able to view question details',()=>{
    browser.element(by.css(".view-comments")).click();
    expect(browser.getCurrentUrl()).toContain('/question-details');
  });

  it('shuld be able to post a comment',()=>{
    browser.element(by.id("comment-field")).sendKeys("Java Is a oops.");
    browser.element(by.id("comment-button")).click();
    expect(browser.getCurrentUrl()).toContain('/question-details');
  });

  it('shuld be able to delete a comment',()=>{
    browser.element(by.css(".delete-comment")).click();
    expect(browser.getCurrentUrl()).toContain('/question-details');
  });

  it('shuld be able to go back to question details',()=>{
    browser.element(by.css(".back-to-question")).click();
    expect(browser.getCurrentUrl()).toContain('/topic-details');
  });
  
  it('shuld be able to delete a question',()=>{
    browser.element(by.css(".delete-question")).click();
    expect(browser.getCurrentUrl()).toContain('/topic-details');
  });

});
