package com.movie.cruiser.mcs.resource;


import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.movie.cruiser.mcs.domain.Movie;
import com.movie.cruiser.mcs.service.MovieService;


@RunWith(SpringRunner.class)
@WebMvcTest(MovieCruiserResource.class)
public class MovieCruiserResourceTest {
	
	@Autowired
	private transient MockMvc mvc;
	
	@MockBean
	private transient MovieService service;
	
	@InjectMocks
	private MovieCruiserResource movieCruiserResource;
	
	private transient Movie movie;
	
	private List<Movie> movies;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mvc = MockMvcBuilders.standaloneSetup(movieCruiserResource).build();
		movies = new ArrayList<>();
		movie = new Movie(1,"123","321", "spiderman", "worth watching", "www.spiderman.com", "2015-03-23", 55.5, 70);
		movies.add(movie);
		movie = new Movie(2,"123","321", "spiderman 2", "very good", "www.spiderman.com", "2015-03-23", 55.5, 70);
		movies.add(movie);
	}
	
	@Test
	public void testSaveMovieSuccess() throws Exception{
		when(service.saveMovie(movie)).thenReturn(true);
		String token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0ZXN0Sm9objEiLCJpYXQiOjE1MzU3MjIzMzF9.vIE3Dhskgk2KWyqdqflaADXb0wTAl2Su7-QF1x298Ac";
		mvc.perform(post("/api/movie").header("authorization", "Bearer "+token).contentType(MediaType.APPLICATION_JSON).content(jsonToString(movie)))
			.andExpect(status().isCreated());
		verify(service, times(1)).saveMovie(Mockito.any(Movie.class));
		verifyNoMoreInteractions(service);
	}
	
	@Test
	public void testUpdateMovieSuccess() throws Exception{
		movie.setComments("Not so bad");
		when(service.updateMovie(movie)).thenReturn(movies.get(0));
		mvc.perform(put("/api/movie",1).contentType(MediaType.APPLICATION_JSON).content(jsonToString(movie)))
		.andExpect(status().isOk());
		verify(service, times(1)).updateMovie(Mockito.any(Movie.class));
		verifyNoMoreInteractions(service);
	}
	
	@Test
	public void testDeleteMovieById() throws Exception{
		when(service.deleteMovieById(1)).thenReturn(true);
		mvc.perform(delete("/api/movie/{id}",1)).andExpect(status().isOk());
		verify(service, times(1)).deleteMovieById(1);
		verifyNoMoreInteractions(service);
	}
	
	@Test
	public void testGetMovieById() throws Exception{
		when(service.getMovieById(1)).thenReturn(movie);
		mvc.perform(get("/api/movie/{id}",1)).andExpect(status().isOk());
		verify(service, times(1)).getMovieById(1);
		verifyNoMoreInteractions(service);
	}
	
	@Test
	public void testGetAllMovies() throws Exception{
		when(service.getAllMovies()).thenReturn(movies);
		mvc.perform(get("/api/movie")).andExpect(status().isOk());
		verify(service, times(1)).getAllMovies();
		verifyNoMoreInteractions(service);
	}
	
	@Test
	public void testgetMyMovieSuccess() throws Exception{
		when(service.getMyMovies("testJohn1")).thenReturn(movies);
		String token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0ZXN0Sm9objEiLCJpYXQiOjE1MzU3MjIzMzF9.vIE3Dhskgk2KWyqdqflaADXb0wTAl2Su7-QF1x298Ac";
		mvc.perform(get("/api/movie/movies").header("authorization", "Bearer "+token).contentType(MediaType.APPLICATION_JSON).content(jsonToString(movie)))
			.andExpect(status().isOk());
		verify(service, times(1)).getMyMovies("testJohn1");
		verifyNoMoreInteractions(service);
	}
	
	private static String jsonToString(final Object obj) throws JsonProcessingException {
		String result;
		try {
			final ObjectMapper mapper= new ObjectMapper();
			final String json=mapper.writeValueAsString(obj);
			result=json;
		}catch(JsonProcessingException e) {
			result = "Json processing error";
		}
		return result;
	}

}
