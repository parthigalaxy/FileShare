package com.movie.cruiser.mcs.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.movie.cruiser.mcs.domain.Movie;
import com.movie.cruiser.mcs.exception.MovieAlreadyExistException;
import com.movie.cruiser.mcs.exception.MovieNotFoundException;
import com.movie.cruiser.mcs.repository.MovieRepository;

public class MovieServiceImplTest {

	@Mock
	private transient MovieRepository movieRepository;
	
	private transient Movie movie;
	
	@InjectMocks
	private transient MovieServiceImpl movieServiceImpl;
	
	/**
	 * TO hold user defined lists
	 */
	private transient Optional<Movie> options;
	
	/**
	 * Initializing object declaration
	 */
	@Before
	public void testMock() {
		MockitoAnnotations.initMocks(this);
		movie = new Movie(1,"123","321", "antman", "worth watching", "www.antman.com", "2015-03-23", 55.5, 70);
		options = Optional.of(movie);
	}
	
	/**
	 * test mock creation
	 */
	@Test
	public void testMockCreation() {
		assertNotNull("use @InjectionMocks on movieServiceImpl", movie);
	}
	
	/**
	 * 
	 * @throws MovieAlreadyExistsException
	 */
	@Test
	public void testSaveMoiveSuccess() throws MovieAlreadyExistException{
		when(movieRepository.save(movie)).thenReturn(movie);
		final boolean flag= movieServiceImpl.saveMovie(movie);
		assertTrue("saving movie failed", flag);
		verify(movieRepository,times(1)).save(movie);
		//verify(movieRepo,times(1)).findById(movie.getId());
	}
	
	@Test(expected=MovieAlreadyExistException.class)
	public void testSaveMovieFailure() throws MovieAlreadyExistException{
		when(movieRepository.findById(movie.getId())).thenReturn(options);
		when(movieRepository.save(movie)).thenReturn(movie);
		final boolean flag= movieServiceImpl.saveMovie(movie);
		assertFalse("saving movie failed", flag);
		verify(movieRepository,times(1)).findById(movie.getId());
	}
	
	/**
	 * 
	 * @throws MovieNotFoundException
	 */
	@Test
	public void testUpdateMovie() throws MovieNotFoundException{
		when(movieRepository.findById(movie.getId())).thenReturn(options);
		when(movieRepository.save(movie)).thenReturn(movie);
		movie.setComments("Neutral");
		final Movie upMovie= movieServiceImpl.updateMovie(movie);
		assertEquals("upadte failed","Neutral",upMovie.getComments());
		verify(movieRepository,times(1)).save(movie);
		verify(movieRepository,times(1)).findById(movie.getId());
	}
	
	/**
	 * 
	 * @throws MovieNotFoundException
	 */
	@Test
	public void testDeleteMovieById() throws MovieNotFoundException{
		when(movieRepository.findById(1)).thenReturn(options);
		doNothing().when(movieRepository).delete(movie);
		final boolean flag= movieServiceImpl.deleteMovieById(1);
		assertTrue("Deleting movie failed",flag);
		//verify(movieRepo,times(1)).delete(movie);
		verify(movieRepository,times(1)).findById(movie.getId());
	}
	
	/**
	 * 
	 * @throws MovieNotFoundException
	 */
	@Test
	public void testGetMovieById() throws MovieNotFoundException{
		when(movieRepository.findById(1)).thenReturn(options);
		final Movie upMovie= movieServiceImpl.getMovieById(1);
		assertEquals("Fetch movie by Id failed",upMovie,movie);
		verify(movieRepository,times(1)).findById(movie.getId());
	}
	
	@Test
	public void testGetAllMovies() {
		final List<Movie> movieList= new ArrayList<>(1);
		when(movieRepository.findAll()).thenReturn(movieList);
		final List<Movie> moviesAll=movieServiceImpl.getAllMovies();
		assertEquals(movieList,moviesAll);
		verify(movieRepository,times(1)).findAll();
	}
	
}