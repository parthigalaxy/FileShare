package com.movie.cruiser.mcs.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.movie.cruiser.mcs.domain.Movie;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@Transactional
public class MovieRepositoryTest {
	
	@Autowired
	public transient MovieRepository movieRepository; 
	
	@Test
	public void testSaveMovie() throws Exception{
		movieRepository.save(new Movie(1,"123","321", "batman", "worth watching", "www.batman.com", "2015-03-23", 55.5, 70));
		final Movie movie=movieRepository.getOne(1);
		assertThat(movie.getId()).isEqualTo(1);
		
	}
	
	@Test
	public void testUpdateMovie() throws Exception{
		movieRepository.save(new Movie(1,"123","321", "batman", "worth watching", "www.batman.com", "2015-03-23", 55.5, 70));
		final Movie movie=movieRepository.getOne(1);
		assertEquals(movie.getName(),"batman");
		movie.setComments("bad batman");
		movieRepository.save(movie);
		final Movie movieUp=movieRepository.getOne(1);
		assertEquals("bad batman", movieUp.getComments());
	}
	
	@Test
	public void testDeleteMovie() throws Exception{
		movieRepository.save(new Movie(1,"123","321", "batman", "worth watching", "www.batman.com", "2015-03-23", 55.5, 70));
		final Movie movie=movieRepository.getOne(1);
		assertEquals(movie.getName(),"batman");
		movieRepository.delete(movie);
		assertEquals(Optional.empty(), movieRepository.findById(1));
	}
	
	@Test
	public void testGetMovie() throws Exception{
		movieRepository.save(new Movie(1,"123","321", "batman", "worth watching", "www.batman.com", "2015-03-23", 55.5, 70));
		final Movie movie=movieRepository.getOne(1);
		assertEquals(movie.getName(),"batman");
	}
	
	@Test
	public void testGetAllMovies() throws Exception{
		movieRepository.save(new Movie(1,"123","321", "batman", "worth watching", "www.batman.com", "2015-03-23", 55.5, 70));
		movieRepository.save(new Movie(2,"123","321", "batman-1", "worth watching", "www.batman.com", "2015-03-23", 55.5, 70));
		final List<Movie> movie=movieRepository.findAll();
		assertEquals(movie.get(0).getName(),"batman");
	}

}
