package com.movie.cruiser.mcs.exception;

@SuppressWarnings("serial")
public class MovieNotFoundException extends Exception{

	private String message;
	
	public MovieNotFoundException(String message) {
		super(message);
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String toString() {
		return "MovieNotFoundException [message :"+message+"]";
	}

}
