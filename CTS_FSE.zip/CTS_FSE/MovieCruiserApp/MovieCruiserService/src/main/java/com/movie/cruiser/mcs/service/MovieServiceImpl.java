package com.movie.cruiser.mcs.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.movie.cruiser.mcs.domain.Movie;
import com.movie.cruiser.mcs.exception.MovieAlreadyExistException;
import com.movie.cruiser.mcs.exception.MovieNotFoundException;
import com.movie.cruiser.mcs.repository.MovieRepository;

@Service
public class MovieServiceImpl implements MovieService{
	
	private static final Logger logger = LoggerFactory.getLogger(MovieServiceImpl.class);
	
	private MovieRepository movieRepository;
	
	public MovieServiceImpl(MovieRepository movieRepository) {
		this.movieRepository = movieRepository;
	}
	

	@Override
	public boolean saveMovie(Movie movie) throws MovieAlreadyExistException {
		logger.debug("MovieServiceImpl > saveMovie > start");
		if(null != movie) {
			Optional<Movie> movieo = movieRepository.findById(movie.getId());
			if(movieo.isPresent()) {
				throw new MovieAlreadyExistException("Could not able to save the movie, Movie Already Exist");
			}
			movieRepository.save(movie);
		}else {
			return false;
		}
		logger.debug("MovieServiceImpl > saveMovie > end");
		return true;
	}

	@Override
	public Movie updateMovie(Movie movieUpdate) throws MovieNotFoundException {
		logger.debug("MovieServiceImpl > updateMovie > start");
		Movie movie = null;
		if(null != movieUpdate) {
			movie = movieRepository.findById(movieUpdate.getId()).orElse(null);
			if(movie == null) {
				throw new MovieNotFoundException("Could not able to update the movie,Movie Not Found");
			}
			movie.setComments(movieUpdate.getComments());
			movieRepository.save(movie);
		}
		logger.debug("MovieServiceImpl > updateMovie > end");
		return movie;
	}

	@Override
	public boolean deleteMovieById(int id) throws MovieNotFoundException {
		logger.debug("MovieServiceImpl > deleteMovieById > start");
		Movie movie = movieRepository.findById(id).orElse(null);
		if(movie == null) {
			throw new MovieNotFoundException("Could not able to delete the movie,Movie Not Found");
		}
		movieRepository.deleteById(id);
		logger.debug("MovieServiceImpl > deleteMovieById > end");
		return true;
	}

	@Override
	public List<Movie> getAllMovies() {
		logger.debug("MovieServiceImpl > getAllMovies > start");
		List<Movie> movies = movieRepository.findAll();	
		logger.debug("MovieServiceImpl > getAllMovies > end");
		return movies;
	}

	@Override
	public Movie getMovieById(int id) throws MovieNotFoundException {
		logger.debug("MovieServiceImpl > getMovieById > start");
		Optional<Movie> movie = movieRepository.findById(id);
		if(!movie.isPresent()) {
			throw new MovieNotFoundException("Could not able to find a movie, Movie Not Found :"+ id);
		}
		logger.debug("MovieServiceImpl > getMovieById > end");
		return movie.get();
	}


	@Override
	public List<Movie> getMyMovies(String userId){
		logger.debug("MovieServiceImpl > getMyMovies > start");
		List<Movie> movies = movieRepository.findByUserId(userId);
		logger.debug("MovieServiceImpl > getMyMovies > end");
		return movies;
	}

}
