package com.movie.cruiser.mcs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.movie.cruiser.mcs.domain.Movie;

@Repository("movieRepository")
public interface MovieRepository extends JpaRepository<Movie, Integer> {

	public List<Movie> findByUserId(String userId);
	
}
