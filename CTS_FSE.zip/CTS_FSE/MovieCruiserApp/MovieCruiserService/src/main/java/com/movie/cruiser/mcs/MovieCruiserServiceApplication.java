package com.movie.cruiser.mcs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

import com.movie.cruiser.mcs.filter.JwtFilter;

@SpringBootApplication
public class MovieCruiserServiceApplication {
	
	@Bean
	public FilterRegistrationBean<JwtFilter> jwtFilter(){
		final FilterRegistrationBean<JwtFilter> filterRegistrationBean = new FilterRegistrationBean<JwtFilter>();
		filterRegistrationBean.setFilter(new JwtFilter());
		filterRegistrationBean.addUrlPatterns("/api/*");
		return filterRegistrationBean;
	}

	public static void main(String[] args) {
		SpringApplication.run(MovieCruiserServiceApplication.class, args);
	}
}
