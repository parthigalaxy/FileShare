package com.movie.cruiser.mcs.service;

import java.util.List;

import com.movie.cruiser.mcs.domain.Movie;
import com.movie.cruiser.mcs.exception.MovieAlreadyExistException;
import com.movie.cruiser.mcs.exception.MovieNotFoundException;

public interface MovieService {
	
	public boolean saveMovie(Movie movie) throws MovieAlreadyExistException;
	public Movie updateMovie(Movie movie) throws MovieNotFoundException;
	public boolean deleteMovieById(int id) throws MovieNotFoundException;
	public Movie getMovieById(int id) throws MovieNotFoundException;
	public List<Movie> getAllMovies();
	public List<Movie> getMyMovies(String userId);

}
