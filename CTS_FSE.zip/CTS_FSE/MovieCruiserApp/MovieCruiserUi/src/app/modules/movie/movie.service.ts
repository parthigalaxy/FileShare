import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Movie } from './movie';
import {map} from 'rxjs/operators/map';
import { Observable } from 'rxjs/Observable';
import { retry } from 'rxjs/operators';
import { environment } from '../../../environments/environment'

@Injectable()
export class MovieService {

  movies: Array<Movie>;
  tmdbEndpoint:string = environment.tmdbEndpoint;
  apiKey:string = environment.api_key;
  posterPathPrefix:string = environment.posterPathPrefix;
  watchListEndPoint:string = environment.watchListEndPoint;
  searchUrl:string = environment.tmdbSearchEndpoint;
  
  constructor(private http:HttpClient) { 
    this.movies = [];
  }

  retrieveMovies(type:string,page: number = 1):Observable<Array<Movie>>{
    let movieUrl = `${this.tmdbEndpoint}/${type}?${this.apiKey}&page=${page}`
    return this.http.get(movieUrl).pipe(
      retry(3),
      map(this.pickMovieResults),
      map(this.transferPosterPath.bind(this))
    );
  }

  transferPosterPath(movies):Array<Movie>{
    return movies.map( movie => {
      movie.poster_path = `${this.posterPathPrefix}`+`${movie.poster_path}`;
      return movie;
    });
  }

  pickMovieResults(response){
    return response['results'];
  }

  retrieveWatchListedMovies():Observable<Array<Movie>>{
    return this.http.get(this.watchListEndPoint).pipe(
      retry(3),
      map(this.movieDomainMapper.bind(this))
    );
  }

  movieDomainMapper(movieDomains):Array<Movie>{
    console.log(JSON.stringify(movieDomains));
    return movieDomains.map( movie => {
      let movieVo:Movie= {
        id : movie.id,
        title : movie.name,
        poster_path:movie.posterPath,
        overview:movie.id,
        release_date:movie.releaseDate,
        comments:movie.comments,
      };
      movieVo.title = movie.name;
      return movieVo;
    });
  }

  addMoviesToWatchList(movie:Movie){
    let movieVo = {
      id : movie.id,
      name : movie.title,
      posterPath:movie.poster_path,
      comments:'',
      releaseDate:movie.release_date
    };
    return this.http.post(this.watchListEndPoint,movieVo);
  }

  deleteMovieFromWatchList(movie:Movie){
    return this.http.delete(this.watchListEndPoint+"/"+movie.id,{responseType:'json'});
  }

  updateMovieInWatchList(movie:Movie){
    let movieVo = {
      id : movie.id,
      name : movie.title,
      posterPath:movie.poster_path,
      comments:movie.comments,
      releaseDate:movie.release_date
    };
    return this.http.put(this.watchListEndPoint,movieVo);
  }

  searchMovies(searchKey:string):Observable<Array<Movie>>{
    if(searchKey.length>0){
      const url = `${this.searchUrl}${this.apiKey}&page=1&include_adult=false&query=${searchKey}`;
      console.log(url);
      return this.http.get(url).pipe(
        retry(3),
        map(this.pickMovieResults),
        map(this.transferPosterPath.bind(this))
      );
    }
  }

}
