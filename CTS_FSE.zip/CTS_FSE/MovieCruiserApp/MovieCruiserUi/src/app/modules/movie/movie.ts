export interface Movie {
    id:string;
    title:string;
    poster_path:string;
    overview:string;
    release_date:string;
    comments:string;
}
