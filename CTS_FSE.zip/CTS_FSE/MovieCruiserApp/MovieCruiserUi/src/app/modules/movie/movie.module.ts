import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import { MovieService } from './movie.service';
import { PopularComponent } from './components/popular/popular.component';
import { ContainerComponent } from './components/container/container.component';
import { TopratedComponent } from './components/toprated/toprated.component';
import { MovieRoutesModule } from './movie-routes.module';
import { MovieMatModule } from '../movie-mat/movie-mat.module';
import { WatchlistComponent } from './components/watchlist/watchlist.component';
import { TmdpcontainerComponent } from './components/tmdpcontainer/tmdpcontainer.component';
import { MovieDailogComponent } from './components/movie-dailog/movie-dailog.component';
import { FormsModule } from '@angular/forms';
import { SearchComponent } from './components/search/search.component'


@NgModule({
  imports: [
    CommonModule,
    MovieRoutesModule,
    MovieMatModule,
    FormsModule
  ],
  declarations: [ThumbnailComponent, PopularComponent, ContainerComponent, TopratedComponent, WatchlistComponent, TmdpcontainerComponent, MovieDailogComponent,MovieDailogComponent, SearchComponent],
  exports:[ThumbnailComponent,PopularComponent,ContainerComponent,MovieRoutesModule,MovieMatModule,MovieDailogComponent,FormsModule,SearchComponent],
  providers:[MovieService],
  entryComponents:[MovieDailogComponent]
})
export class MovieModule { }
