import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';

@Component({
  selector: 'movie-watchlist',
  templateUrl: './watchlist.component.html',
  styleUrls: ['./watchlist.component.css']
})
export class WatchlistComponent implements OnInit {

  movies: Array<Movie>;
  isWatchList:boolean = true;
  constructor(private movieService: MovieService,private route:ActivatedRoute) { 
    this.movies = [];
  }

  ngOnInit() {
    this.movieService.retrieveWatchListedMovies().subscribe( (movies) => {
       this.movies.push(...movies);
    });
  }

}
