import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';

@Component({
  selector: 'movie-toprated',
  templateUrl: './toprated.component.html',
  styleUrls: ['./toprated.component.css']
})
export class TopratedComponent implements OnInit {

  movies: Array<Movie>;
  type:string;

  constructor(private movieService: MovieService,private route:ActivatedRoute) { 
    this.movies = [];
    this.type = '';
  }

  ngOnInit() {
    this.route.data.subscribe(data => this.type = data.movieType);
    this.movieService.retrieveMovies(this.type).subscribe( (movies) => {
       this.movies.push(...movies);
    });
  }
}
