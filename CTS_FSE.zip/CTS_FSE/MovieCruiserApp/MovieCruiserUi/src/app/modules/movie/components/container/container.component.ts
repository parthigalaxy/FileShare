import { Component, OnInit,Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';
import { MatSnackBar } from "@angular/material/snack-bar"

@Component({
  selector: 'movie-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.css']
})
export class ContainerComponent implements OnInit {

  @Input()
  movies: Array<Movie>;

  @Input()
  isWatchList:boolean;
  
  constructor(private movieService: MovieService,private snackBar:MatSnackBar) { 
    this.movies = [];
  }

  ngOnInit() {
    
  }

  deleteMovieFromWatchList(movie){
    let message = movie.title +" Movie Deleted from watchlist!";
    for(var i=0;i < this.movies.length;i++){
      if(this.movies[i].title === movie.title){
        this.movies.splice(i,1);
      }
    }
    this.movieService.deleteMovieFromWatchList(movie).subscribe((movie)=>{
      this.snackBar.open(message,"",{duration:1000});
    });
  }

}
