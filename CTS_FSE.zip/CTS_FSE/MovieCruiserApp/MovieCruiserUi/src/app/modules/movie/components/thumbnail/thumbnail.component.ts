import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';
import { MatSnackBar } from "@angular/material/snack-bar";
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { MovieDailogComponent } from '../movie-dailog/movie-dailog.component';

@Component({
  selector: 'app-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css']
})
export class ThumbnailComponent implements OnInit {

  @Input()
  movie : Movie;

  @Input()
  isWatchList:boolean;

  @Output()
  deleteMovie : EventEmitter<Movie>= new EventEmitter();

  constructor(private movieService: MovieService,private snackBar:MatSnackBar,public dialog: MatDialog) {}

  ngOnInit() {
   
  }

  addMovieToWatchList(){
    this.movieService.addMoviesToWatchList(this.movie).subscribe((movie)=>{
      console.log("Movie added successfully!"+ movie);
      this.snackBar.open("Movie added successfully!","",{duration:1000});
    });
  }

  deleteMovieFromWatchList(){
    this.deleteMovie.emit(this.movie);
  }

  updateMovieInWatchList(actionType){
    console.log("Movie is getting updated");
    let dialogRef = this.dialog.open(MovieDailogComponent,{
      width:'400px',
      data:{obj:this.movie,actionType:actionType}
    });
    console.log("open Dailog");
    dialogRef.afterClosed().subscribe(result => {
      console.log("The Dailog was closed");
    });
  }

}
