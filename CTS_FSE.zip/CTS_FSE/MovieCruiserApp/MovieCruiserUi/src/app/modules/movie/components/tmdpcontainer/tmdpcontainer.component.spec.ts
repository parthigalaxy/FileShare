import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TmdpcontainerComponent } from './tmdpcontainer.component';

describe('TmdpcontainerComponent', () => {
  let component: TmdpcontainerComponent;
  let fixture: ComponentFixture<TmdpcontainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TmdpcontainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TmdpcontainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
