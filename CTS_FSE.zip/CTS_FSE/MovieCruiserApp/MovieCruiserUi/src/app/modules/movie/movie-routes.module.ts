import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { PopularComponent } from './components/popular/popular.component';
import { TopratedComponent } from './components/toprated/toprated.component';
import { TmdpcontainerComponent } from './components/tmdpcontainer/tmdpcontainer.component';
import { WatchlistComponent } from './components/watchlist/watchlist.component';
import { SearchComponent } from './components/search/search.component';

const movie_routes:Routes = [
  {
    path:"movies",
    children:[
      {
        path:"",
        redirectTo:"movies/popular",
        pathMatch:"full"
      },
      {
        path:"popular",
        component:TmdpcontainerComponent,
        data:{
          movieType : "popular"
        }
      },
      {
        path:"toprated",
        component:TmdpcontainerComponent,
        data:{
          movieType : "top_rated"
        }
      },
      {
        path:"watchlist",
        component:WatchlistComponent
      },
      {
        path:"search",
        component:SearchComponent
      }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(movie_routes)
  ],
  declarations: [],
  exports:[RouterModule]
})
export class MovieRoutesModule { }
