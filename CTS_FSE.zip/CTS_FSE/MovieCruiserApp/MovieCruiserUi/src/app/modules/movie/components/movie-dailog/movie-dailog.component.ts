import { Component, OnInit, Input,Inject } from '@angular/core';
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';
import { MatSnackBar } from "@angular/material/snack-bar"
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material"

@Component({
  selector: 'movie-movie-dailog',
  templateUrl: './movie-dailog.component.html',
  styleUrls: ['./movie-dailog.component.css']
})
export class MovieDailogComponent implements OnInit {

  movie:Movie;
  comments:string;
  actionType:string;

  constructor(private movieService: MovieService,private snackBar:MatSnackBar,
  public dialogRef:MatDialogRef<MovieDailogComponent>,@Inject(MAT_DIALOG_DATA) public data: any) { 
    this.comments=data.obj.comments;
    this.movie=data.obj;
    this.actionType=data.actionType;
  }

  ngOnInit() {
    console.log(this.data);
  }

  onNoClick(){
    this.dialogRef.close();
  }

  updateComments(){
    console.log("comments" , this.comments);
    this.movie.comments = this.comments;
    this.dialogRef.close();
    this.movieService.updateMovieInWatchList(this.movie).subscribe(movie=>{
      this.snackBar.open("Movie updated to WatchList Successfully","",{duration:2000});
    });
  }
}
