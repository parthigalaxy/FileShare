export const environment = {
  production: true,
  tmdbEndpoint: "https://api.themoviedb.org/3/movie",
  api_key:"api_key=83fe9abcff73e9623a642f10a577fe5f",
  posterPathPrefix:"https://image.tmdb.org/t/p/w500",
  watchListEndPoint:"http://localhost:8081/api/movie",
  tmdbSearchEndpoint: "https://api.themoviedb.org/3/search/movie?"
};
