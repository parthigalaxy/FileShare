sudo docker login --username="parthigalaxy" --password="dockergalaxy"
