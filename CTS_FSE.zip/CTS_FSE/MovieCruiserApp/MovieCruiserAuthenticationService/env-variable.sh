export MYSQL_DATABASE=moviecruiser
export MYSQL_USER=root
export MYSQL_PASSWORD=root
export MYSQL_CI_URL=jdbc:mysql://localhost:3306/moviecruiser