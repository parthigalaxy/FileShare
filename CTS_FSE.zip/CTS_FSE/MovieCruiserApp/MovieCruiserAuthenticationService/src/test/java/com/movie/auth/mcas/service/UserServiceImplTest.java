package com.movie.auth.mcas.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.movie.auth.mcas.domain.User;
import com.movie.auth.mcas.exception.UserAlreadyExistException;
import com.movie.auth.mcas.exception.UserNotFoundException;
import com.movie.auth.mcas.repository.UserRepository;

public class UserServiceImplTest {

	@Mock
	private transient UserRepository userRepository;
	
	private transient User user;
	
	@InjectMocks
	private transient UserServiceImpl userServiceImpl;

	private transient Optional<User> options;

	@Before
	public void testMock() {
		MockitoAnnotations.initMocks(this);
		user = new User("testJohn123", "John", "Jenny", "123456", new Date());
		options = Optional.of(user);
	}
	
	@Test
	public void testMockCreation() {
		assertNotNull("use @InjectionMocks on movieServiceImpl", user);
	}
	
	@Test
	public void testSaveUserSuccess() throws UserAlreadyExistException, UserNotFoundException{
		when(userRepository.save(this.user)).thenReturn(user);
		final boolean flag= userServiceImpl.saveUser(user);
		assertEquals("User registred successfully ", true, flag);
		verify(userRepository,times(1)).save(user);
	}
	
	@Test(expected=UserAlreadyExistException.class)
	public void testSaveUserFailure() throws UserAlreadyExistException, UserNotFoundException{
		when(userRepository.findById(user.getUserId())).thenReturn(options);
		when(userRepository.save(user)).thenReturn(user);
		userServiceImpl.saveUser(user);
	}
	
	@Test
	public void testValidateUserSuccess() throws UserNotFoundException{
		when(userRepository.findByUserIdAndPassword(user.getUserId(), user.getPassword())).thenReturn(user);
		User userRes = userServiceImpl.findByUserIdAndPassword(user.getUserId(), user.getPassword());
		assertNotNull(userRes);
		assertEquals("testJohn123", userRes.getUserId());
		verify(userRepository,times(1)).findByUserIdAndPassword(user.getUserId(), user.getPassword());
	}
	
	@Test(expected=UserNotFoundException.class)
	public void testValidateUserFailure() throws UserNotFoundException{
		when(userRepository.findByUserIdAndPassword(user.getUserId(), user.getPassword())).thenReturn(null);
		userServiceImpl.findByUserIdAndPassword(user.getUserId(), user.getPassword());
	}
	
}