package com.movie.auth.mcas.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Date;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.movie.auth.mcas.domain.User;


@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@Transactional
public class UserRepositoryTest {
	
	@Autowired
	public transient UserRepository userRepository; 
	
	private User user;
	private User user1;
	
	@Before
	public void setup() throws Exception{
		user = new User("testJohn", "John", "Jenny", "123456", new Date());
		user1 = new User("testJohn1", "John", "Jenny", "123456", new Date());
	}
	
	@Test
	public void testRegisterUserSuccess() throws Exception{
		userRepository.save(this.user);
		Optional<User> userO = userRepository.findById(this.user.getUserId());
		assertThat(userO.equals(this.user));
	}
	
	@Test
	public void testFindByUserIdAndPasswordSuccess() throws Exception{
		userRepository.save(this.user1);
		User userResp = userRepository.findByUserIdAndPassword(this.user1.getUserId(), this.user1.getPassword());
		assertThat(userResp.equals(user));
	}
	
//	@Test
//	public void testDeleteByUserIdSuccess() throws Exception{
//		userRepository.deleteById(this.user.getUserId());
//		Optional<User> userO = userRepository.findById(this.user.getUserId());
//		assertThat(!userO.isPresent());
//	}


}
