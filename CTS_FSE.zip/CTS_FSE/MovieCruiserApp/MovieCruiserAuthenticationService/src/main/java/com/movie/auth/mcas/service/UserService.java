package com.movie.auth.mcas.service;

import com.movie.auth.mcas.domain.User;
import com.movie.auth.mcas.exception.UserAlreadyExistException;
import com.movie.auth.mcas.exception.UserNotFoundException;

public interface UserService {
	
	boolean saveUser(User user) throws UserAlreadyExistException,UserNotFoundException;
	
	User findByUserIdAndPassword(String userId,String password) throws UserNotFoundException;

}
