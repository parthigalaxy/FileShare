package com.movie.auth.mcas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieCruiserAuthenticationService 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(MovieCruiserAuthenticationService.class, args);
    }
}
