package com.movie.auth.mcas.exception;

@SuppressWarnings("serial")
public class UserNotFoundException extends Exception{

	private String message;
	
	public UserNotFoundException(String message) {
		super(message);
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String toString() {
		return "MovieNotFoundException [message :"+message+"]";
	}

}
