package com.movie.auth.mcas.exception;

@SuppressWarnings("serial")
public class UserAlreadyExistException extends Exception {
	
	private String message;
	
	public UserAlreadyExistException(String message) {
		super(message);
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String toString() {
		return "MovieAlreadyExistException [message :"+message+"]";
	}

}
