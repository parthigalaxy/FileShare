package com.movie.auth.mcas.service;

import java.util.Map;

import com.movie.auth.mcas.domain.User;

public interface SecurityTokenGenrator {
	
	Map<String,String> geneateToken(User user);

}
