package com.movie.auth.mcas.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.auth.mcas.domain.User;
import com.movie.auth.mcas.exception.UserAlreadyExistException;
import com.movie.auth.mcas.exception.UserNotFoundException;
import com.movie.auth.mcas.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	
	private UserRepository userRepository;
	
	@Autowired
	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	@Override
	public boolean saveUser(User user) throws UserAlreadyExistException, UserNotFoundException {
		String userId = (null != user)?user.getUserId():null;
		if(userId == null) {
			throw new UserNotFoundException("Please check the user id");
		}
		Optional<User> userO = userRepository.findById(userId);
		if(userO.isPresent()) {
			throw new UserAlreadyExistException("User with Id is alrady exist");
		}
		userRepository.save(user);
		return true;
	}

	@Override
	public User findByUserIdAndPassword(String userId, String password) throws UserNotFoundException {
		User user = userRepository.findByUserIdAndPassword(userId, password);
		if(user == null) {
			throw new UserNotFoundException("Please check the user id");
		}
		return user;
	}

}
