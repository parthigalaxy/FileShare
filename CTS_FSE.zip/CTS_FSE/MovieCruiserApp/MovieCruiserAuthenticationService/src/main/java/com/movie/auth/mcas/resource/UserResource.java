package com.movie.auth.mcas.resource;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.movie.auth.mcas.domain.User;
import com.movie.auth.mcas.exception.UserAlreadyExistException;
import com.movie.auth.mcas.exception.UserNotFoundException;
import com.movie.auth.mcas.service.SecurityTokenGenrator;
import com.movie.auth.mcas.service.UserService;

@CrossOrigin
@RestController
@EnableWebMvc
@RequestMapping("/user")
public class UserResource {
	
	private static final Logger logger = LoggerFactory.getLogger(UserResource.class);
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private SecurityTokenGenrator securityTokenGenrator;
	
	@PostMapping("/register")
	public @ResponseBody ResponseEntity<?> registerUser(@RequestBody final User user){
		logger.debug("UserResource > registerUser > start");
		ResponseEntity<?> responseEntity;
		try {
			userService.saveUser(user);
			responseEntity = new ResponseEntity<String>("{\"message\":\" User Registred Successfully \"}",HttpStatus.CREATED);
		} catch (UserAlreadyExistException|UserNotFoundException e) {
			logger.error("UserResource > registerUser > UserAlreadyExistException|UserNotFoundException",e);
			responseEntity = new ResponseEntity<String>("{\"message\":\""+e.getMessage()+"\"}",HttpStatus.CONFLICT);
		} 
		logger.debug("UserResource > registerUser > end");
		return responseEntity;
	}
	
	@PostMapping("/login")
	public @ResponseBody ResponseEntity<?> loginUser(@RequestBody final User user){
		logger.debug("UserResource > loginUser > start");
		ResponseEntity<?> responseEntity;
		try {
			if(null == user || StringUtils.isEmpty(user.getUserId()) || StringUtils.isEmpty(user.getPassword())) {
				throw new Exception("UserName or Password Cannot be Empty");
			}
			User userResp = userService.findByUserIdAndPassword(user.getUserId(), user.getPassword());
			if(null == userResp) {
				throw new UserNotFoundException("User with given id does not exists");
			}
			
			if(!userResp.getPassword().equals(user.getPassword())) {
				throw new Exception("Invalid login credential, Please check username and passsword");
			}
			
			Map<String, String> jwtTokenMap  = securityTokenGenrator.geneateToken(userResp);
			responseEntity = new ResponseEntity<Map<String, String>>(jwtTokenMap,HttpStatus.OK);
		} catch (Exception e) {
			logger.error("UserResource > registerUser > Exception",e);
			responseEntity = new ResponseEntity<String>("{\"message\":\""+e.getMessage()+"\"}",HttpStatus.UNAUTHORIZED);
		} 
		logger.debug("UserResource > loginUser > end");
		return responseEntity;
	}

}
